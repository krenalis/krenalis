# Ricerca delle proprietà degli eventi CDP

**Estensione 1.0.0 · Base eventi 1.1.0 · Ricerca verificata il 29 ottobre 2026**

## Perimetro e fonte autorevole

Questa estensione aggiunge proprietà tipizzate alle **102 definizioni esistenti**. Il catalogo eventi originale resta immutato: identificatori, matcher, binding, classificazioni e descrizioni degli eventi non sono sostituiti. La baseline completa è identificata da SHA-256 `d5916ec4e0b0580a6f5263214f1bdbdfdaa4f6f2e6870df83a9207d0dfc3d684`.

`cdp-event-properties.json` è la fonte autorevole delle nuove definizioni. Schemi dei payload, CSV ed Excel sono derivati da questo JSON, evitando contratti paralleli. Le nuove descrizioni delle proprietà sono originali e in inglese; le fonti sono registrate separatamente, con provider, URL, sezione, natura dell’evidenza e ambito applicabile.

Sono stati confrontati tabelle, prosa ed esempi ufficiali. La ricerca supera l’elenco iniziale `key_properties`, ma non pretende di censire ogni estensione possibile di tutti gli SDK o delle destinazioni. Un campo non documentato non è considerato vietato.

## Inventario e copertura

Il catalogo contiene **1.309 campi nominati**: **1.121 specifici degli eventi e 188 condivisi**. Il conteggio esclude **117 container strutturali nominati** e **57 elementi anonimi di array**, necessari alla composizione dei percorsi. **39 campi hanno tipo sconosciuto**; 1.270 possiedono almeno un’alternativa conosciuta. Per provenienza della definizione: 1.052 campi documentati, 111 ricavati da esempi ufficiali e 146 proposti dalla CDP.

| Categoria primaria della baseline | Eventi | Campi specifici |
|---|---:|---:|
| Sito generalista | 17 | 73 |
| Ecommerce | 36 | 517 |
| B2B SaaS e gruppi | 8 | 21 |
| Contenuti | 5 | 26 |
| Video | 17 | 353 |
| Email | 5 | 52 |
| Live chat | 4 | 32 |
| Esperimenti | 1 | 4 |
| Lead avanzati | 2 | 10 |
| Abbonamenti | 4 | 20 |
| Primitive tecniche aggiuntive | 2 | 9 |
| Primitive storiche | 1 | 4 |
| **Totale** | **102** | **1.121** |

Le categorie seguono l’assegnazione primaria del catalogo, non il conteggio autonomo delle tassonomie dei provider. I sei set condivisi sono `common_message`, `context`, `track_common`, `identify_traits`, `context_user_traits` e `group_traits`. L’espansione dei riferimenti produce **11.147 righe nel CSV**, comprese le ripetizioni dei campi condivisi e i nodi strutturali: non sono 11.147 proprietà semanticamente distinte.

## Tipi, strutture e profili di validazione

I metadati distinguono tipi dichiarati, tipi osservati in esempi, proposte CDP e informazione sconosciuta. `type: null` significa tipo ignoto; `type: ["null"]` indica invece un valore JSON nullo documentato. Un numero negli esempi non diventa automaticamente `integer`. Assenza facoltativa e valore esplicito `null` restano distinti.

Gli oggetti conservano i figli in `properties`; gli array descrivono gli elementi in `items`. Il percorso `properties.products[].category` identifica una proprietà del singolo prodotto. `array_ancestors` permette al consumatore di applicare categoria e prezzo allo **stesso elemento**. Questa informazione strutturale non introduce un linguaggio di query o un server MCP.

Il tipo degli elementi resta attribuito alla propria evidenza: un provider che documenta soltanto Array non eredita il tipo degli elementi dall’altro provider. Campi personalizzati rimangono ammessi a ogni livello; gli oggetti con struttura incompleta restano aperti.

Sono disponibili due profili Draft 2020-12:

- **`documented`**, predefinito: applica i tipi espliciti; esempi ufficiali contraddittori possono ampliarne le alternative. Tipi soltanto esemplificati o proposti dalla CDP restano annotazioni. Se un provider documenta il campo ma lascia ignoto quel tipo, il profilo portabile mantiene il valore senza vincolo di tipo.
- **`catalog_contract`**, facoltativo: applica anche quei tipi candidati quando il contratto locale li adotta. I tipi ignoti restano liberi. Le evidenze riservate a una destinazione, come GA4, sono escluse anche da questo profilo universale.

Un campo diventa obbligatorio nel contratto portabile solo con requisiti espliciti concordanti dei due provider e senza dichiarazioni di opzionalità incompatibili. Vincoli condizionali e campi generati dagli SDK rimangono distinti. Non si deducono `required`, enumerazioni, formati, minimi o cardinalità dalla semplice presenza in una tabella o in un payload. La selezione dell’evento usa il matcher invariato: `x-cdp-event-selector` è un’annotazione, non un secondo matcher imposto dallo schema.

## Differenze documentali rilevanti

**Importi ecommerce.** `subtotal`, `total`, `revenue`, `discount` e `price` mantengono descrizioni contestuali. In Order Completed, Segment esplicita l’aggiunta di spedizione e imposte al subtotal. L’esempio Segment usa revenue e subtotal pari a 22,5; RudderStack usa rispettivamente 50 e 45. Non si assume quindi `revenue == subtotal` né una formula universale per Updated, Cancelled o Refunded. La tabella Segment di Order Refunded elenca solo `order_id`: prodotti, totale e valuta hanno prove ulteriori di natura diversa. Gli importi non attestano automaticamente incasso definitivo, profitto o consegna. Fonti: [Segment Ecommerce](https://www.twilio.com/docs/segment/connections/spec/ecommerce/v2), [RudderStack Ordering](https://www.rudderstack.com/docs/event-spec/ecommerce-events-spec/ordering/).

**Conflitti di tipo.** Track dichiara `properties.value` numerico in [Segment](https://www.twilio.com/docs/segment/connections/spec/track) e stringa in [RudderStack](https://www.rudderstack.com/docs/event-spec/standard-events/track/). Le tabelle ecommerce dichiarano `rating` stringa, mentre l’esempio Track RudderStack usa `3.0`: il catalogo conserva stringa e numero, senza inventare una scala. Negli esempi ufficiali si mantengono anche grafie divergenti; `coupon` nel payload malformato Coupon Denied non viene corretto automaticamente in `coupon_id`.

**Identità e collocazione.** Segment Identify usa `traits` a root; RudderStack documenta normalmente `context.traits`, con variazioni SDK conservate. I tratti del gruppo restano distinti da quelli della persona. `traits.employees` è stringa nelle tabelle Group ma numero negli esempi. La `location` dell’esempio Lead Captured descrive una posizione nell’interfaccia, non una geolocalizzazione. Nessuna rinomina sposta questi dati fra sezioni.

**Elementi degli array e video.** Per Page `keywords`, Segment documenta elementi stringa; RudderStack dichiara soltanto Array. Nei video, singolari/plurali, rappresentazioni scalari/array e null degli esempi sono conservati per evento. I quattro campi Quality Updated — `bitrate`, `framerate`, `startupTime`, `droppedFrames` — restano di tipo sconosciuto: non ereditano tipi da altri gruppi video e `droppedFrames` non diventa arbitrariamente un contatore o un booleano.

**Eredità storica.** `mergeProperties` è Object nella tabella RudderStack Merge e array di oggetti nell’esempio. Le due forme e i figli attestati vengono conservati, senza ricostruire membri sconosciuti della forma oggetto né riattivare il metodo storico.

## Convenzioni CDP e precisazioni sulla baseline

Le proprietà aggiunte per pagamenti, richieste di rimborso, resi, stati locali e altre definizioni suggerite sono marcate `cdp_proposed`, facoltative salvo un contratto locale esplicito. Anche un evento di categoria B può avere proprietà proposte: l’attestazione del nome non standardizza il payload. Nessuna garanzia di unicità globale viene aggiunta agli identificatori.

Due precisazioni sono conservate in `original_catalog_issues`: i campi di Lead Captured derivano da un esempio ufficiale, non da una tabella tipizzata; `product_id` di Product Shipped, originariamente suggerito dalla CDP, compare anche nell’esempio Ruby ufficiale. La baseline non viene modificata.

## Audit delle descrizioni e limiti

L’audit sul JSON finale ha esaminato **1.483 descrizioni di nodi, 799 testi distinti**: 1.309 campi, 117 container strutturali nominati e 57 elementi anonimi degli array. Il confronto con **37 testi sorgente** (32 hash distinti, duplicati dichiarati) non ha trovato sequenze identiche di 12 parole né candidati individuati dai marcatori italiani. La revisione ha corretto **19 descrizioni di `position`**, eliminando l’implicazione non documentata che una lista fosse stata visualizzata, e **32 descrizioni di elementi scalari**, rimuovendo un riferimento improprio ad attributi di oggetto. Non restano rilievi aperti. Il file `description-audit.json` identifica tramite SHA-256 il catalogo effettivamente esaminato.

Questi controlli non provano originalità assoluta: frasi più brevi, parafrasi vicine, fonti non conservate e limiti di estrazione possono sfuggire. Il controllo lessicale è affiancato da una revisione editoriale. Il validatore offline verifica che l’audit corrisponda esattamente al catalogo e copra tutti i suoi nodi; non riscarica le fonti e non ripete il confronto testuale. La validità di un payload non dimostra strumentazione corretta, copertura degli eventi, risoluzione dell’identità o correttezza finanziaria. Gli esiti della suite realmente eseguita sono nel separato `validation-report.md`.

## Fonti ufficiali

Il registro contiene URL e sezioni puntuali riferiti a **35 pagine ufficiali distinte**:

- **Segment, protocollo:** [Common Fields](https://www.twilio.com/docs/segment/connections/spec/common), [Page](https://www.twilio.com/docs/segment/connections/spec/page), [Screen](https://www.twilio.com/docs/segment/connections/spec/screen), [Track](https://www.twilio.com/docs/segment/connections/spec/track), [Identify](https://www.twilio.com/docs/segment/connections/spec/identify), [Group](https://www.twilio.com/docs/segment/connections/spec/group), [Alias](https://www.twilio.com/docs/segment/connections/spec/alias), [HTTP API](https://www.twilio.com/docs/segment/connections/sources/catalog/libraries/server/http-api).
- **Segment, specifiche semantiche:** [Ecommerce V2](https://www.twilio.com/docs/segment/connections/spec/ecommerce/v2), [B2B SaaS](https://www.twilio.com/docs/segment/connections/spec/b2b-saas), [Video](https://www.twilio.com/docs/segment/connections/spec/video), [Email](https://www.twilio.com/docs/segment/connections/spec/email), [Live Chat](https://www.twilio.com/docs/segment/connections/spec/live-chat), [A/B Testing](https://www.twilio.com/docs/segment/connections/spec/ab-testing).
- **Segment, raccomandazioni:** [Planning a Full Installation](https://www.twilio.com/docs/segment/getting-started/03-planning-full-install), [Full Implementation](https://www.twilio.com/docs/segment/getting-started/04-full-install), [Data Collection Best Practices](https://www.twilio.com/docs/segment/protocols/tracking-plan/best-practices).
- **RudderStack, protocollo e video:** [Common Fields](https://www.rudderstack.com/docs/event-spec/standard-events/common-fields/), [Page](https://www.rudderstack.com/docs/event-spec/standard-events/page/), [Screen](https://www.rudderstack.com/docs/event-spec/standard-events/screen/), [Track](https://www.rudderstack.com/docs/event-spec/standard-events/track/), [Identify](https://www.rudderstack.com/docs/event-spec/standard-events/identify/), [Group](https://www.rudderstack.com/docs/event-spec/standard-events/group/), [Alias](https://www.rudderstack.com/docs/event-spec/standard-events/alias/), [Merge](https://www.rudderstack.com/docs/event-spec/standard-events/merge/), [Video](https://www.rudderstack.com/docs/event-spec/standard-events/video-events-spec/).
- **RudderStack, ecommerce:** [Browsing](https://www.rudderstack.com/docs/event-spec/ecommerce-events-spec/browsing/), [Ordering](https://www.rudderstack.com/docs/event-spec/ecommerce-events-spec/ordering/), [Promotions](https://www.rudderstack.com/docs/event-spec/ecommerce-events-spec/promotions/), [Coupons](https://www.rudderstack.com/docs/event-spec/ecommerce-events-spec/coupons/), [Wishlist](https://www.rudderstack.com/docs/event-spec/ecommerce-events-spec/wishlisting/), [Sharing](https://www.rudderstack.com/docs/event-spec/ecommerce-events-spec/sharing/), [Reviewing](https://www.rudderstack.com/docs/event-spec/ecommerce-events-spec/reviewing/).
- **Fonti applicative:** [RudderStack Ruby SDK](https://www.rudderstack.com/docs/sources/event-streams/sdks/rudderstack-ruby-sdk/) e [GA4 Cloud Mode](https://www.rudderstack.com/docs/destinations/streaming-destinations/google-analytics-4/cloud-mode/), con ambito specifico preservato.

## Riproduzione

È richiesto Python 3.10 o successivo; l’esecuzione verificata usa Python 3.12.14. Dalla directory degli artefatti:

```bash
python -m pip install -r requirements.txt
python generate_event_schemas.py
python export_event_properties.py
python validate_event_properties.py
```

`requirements.txt` fissa `jsonschema[format]==4.26.0`. Il generatore produce gli schemi; l’esportatore rigenera il CSV e, con `--json-rows`, i dati tabellari intermedi. Non rigenera autonomamente l’Excel: il validatore confronta il workbook consegnato con gli stessi valori derivati dal JSON, oltre a baseline, metadati, schemi e fixture. Per un contratto locale, `python generate_event_schemas.py --profile catalog_contract` genera per impostazione predefinita `cdp-event-payload-schemas.catalog-contract.json`; `--output` permette di scegliere un altro percorso. La verifica documentale resta separata dall’esecuzione dei test.

## Lettura e importazione

I file della directory `baseline/` sono copie byte per byte dei quattro artefatti originali utilizzati per controllare i riferimenti. L’estensione si importa associando `events[].event_id` agli ID della baseline; i set in `property_set_refs` devono essere risolti prima di esporre l’elenco dei campi. Il consumatore mantiene insieme `type`, `provenance`, `provider_evidence` e `contract_scope`: una possibile rappresentazione non è automaticamente un contratto universale né autorizza da sola operatori di filtro.

Il foglio Excel `Properties` riproduce tutte le 11.147 righe del CSV; il foglio `Events` permette di consultare copertura e riferimenti condivisi per le 102 definizioni. I filtri nativi e le intestazioni bloccate servono alla consultazione. Il JSON resta l’unico punto da modificare per aggiornare le definizioni; una modifica richiede rigenerazione degli schemi e delle esportazioni e una nuova validazione.

## Struttura del pacchetto e integrità

La cartella `fixtures/` contiene i payload positivi e negativi, i metadati da respingere, i casi di correlazione sullo stesso elemento e i casi sintattici JSON. Le copie intermedie di ricerca e i testi integrali delle pagine web non sono necessari per eseguire la suite e non fanno parte del pacchetto.

`MANIFEST.sha256` registra gli hash della consegna. Il confronto degli hash va eseguito prima di rieseguire il validatore: una nuova esecuzione aggiorna intenzionalmente timestamp ed esiti di `validation-report.md` e `validation-results.json`. Gli input del catalogo, gli schemi, le fixture e le esportazioni non vengono modificati dalla validazione.
