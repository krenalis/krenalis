# Validazione delle proprietà degli eventi CDP

**Esito: PASSED.** 260 controlli eseguiti, 260 superati, 0 falliti.

Esecuzione UTC: 2026-10-29T14:24:27.559023+00:00. Python 3.12.14; jsonschema 4.26.0.

## Copertura effettiva

- Eventi: **102**, con ID, versione, classificazione e matcher confrontati con il catalogo v1.1.0.
- Campi nominati: **1309**, di cui **1121** specifici degli eventi e **188** condivisi.
- Container strutturali nominati aggiunti per comporre i percorsi: **117**. Tipi non determinabili: **39**.
- Righe di proprietà risolte per evento, inclusi i campi condivisi: **11147**.
- Schemi payload consegnati: **102**. Verificato anche il profilo alternativo catalog_contract generato in memoria.
- Celle Excel confrontate con i valori derivati dal JSON: **222940** nel foglio Properties e **918** nel foglio Events.
- Audit descrizioni collegato allo stesso hash: **1483** nodi. Il validatore controlla collegamento e copertura; non riesegue il confronto con le pagine web.

## Controlli eseguiti

| Categoria | Eseguiti | Superati | Falliti |
|---|---:|---:|---:|
| array_structure | 5 | 5 | 0 |
| baseline | 4 | 4 | 0 |
| constraints | 2 | 2 | 0 |
| coverage | 3 | 3 | 0 |
| descriptions | 3 | 3 | 0 |
| exports | 6 | 6 | 0 |
| generation | 2 | 2 | 0 |
| integrity | 1 | 1 | 0 |
| json_syntax | 17 | 17 | 0 |
| negative_fixture | 26 | 26 | 0 |
| payload_fixture | 84 | 84 | 0 |
| provenance | 1 | 1 | 0 |
| references | 1 | 1 | 0 |
| schema | 105 | 105 | 0 |

## Anomalie

Nessun errore rilevato dai controlli eseguiti.

## Riproduzione

```bash
python -m pip install -r requirements.txt
python generate_event_schemas.py
python export_event_properties.py
python validate_event_properties.py
```

Il validatore legge gli input senza modificarli e aggiorna soltanto i due rapporti. Exit code 0 indica che tutti i controlli sono passati; 1 indica almeno un errore.

## Limiti

- No live CDP, Segment/RudderStack SDK, destination, or MCP service is called by this validator.
- Documentary completeness and semantic accuracy require source review; offline checks verify the captured evidence and artifacts.
- Descriptions were authored in English. A language declaration or phrase-overlap scan alone cannot prove semantic accuracy or legal originality.
- The default schema is deliberately partial. Example-only and CDP-proposed types are annotations until the catalog_contract profile is selected.
- Event selection remains the unchanged base matcher. Cross-field and destination-specific requirements are not silently made universal.

La revisione delle fonti, le contraddizioni documentali e il controllo delle descrizioni sono descritti in `event-properties-research.md`. I singoli esiti e gli hash degli input sono in `validation-results.json`.
