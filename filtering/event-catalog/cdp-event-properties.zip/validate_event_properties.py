#!/usr/bin/env python3
"""Validate the delivered property catalog, generated schemas and exports.

Runs offline against the files beside this script. Reports actual checks only.
No input is modified; validation-report.md and validation-results.json are
the only outputs. Requires jsonschema[format] as listed in requirements.txt.
"""
from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import io
import json
import platform
import re
import sys
import xml.etree.ElementTree as ET
import zipfile
from collections import Counter
from datetime import datetime, timezone
from importlib.metadata import version
from pathlib import Path
from urllib.parse import urlparse

from jsonschema import Draft202012Validator, FormatChecker
from generate_event_schemas import (strict_json, canonical_bytes, build_collection, expand_event,
                                    walk_nodes, selected_types, is_required)
from export_event_properties import COLUMNS, export_rows, csv_bytes

BASE_SHA256 = 'd5916ec4e0b0580a6f5263214f1bdbdfdaa4f6f2e6870df83a9207d0dfc3d684'
BASE_FILES = {
    'cdp-event-catalog.json': BASE_SHA256,
    'cdp-event-catalog.schema.json': '3eaa729051827bf52e137e53ab73dc627bc74bf51022ab62b720a93823eef01c',
    'cdp-event-bindings.json': '99d8cfab376b45e2a51ddfe17b22692abc3da2835dafe2ea497722102895fc2c',
    'cdp-event-bindings.schema.json': 'e33abd4a3c28f81bb7ddab954702be3162e9307556370affc995a76c42b0e3d2',
}
TYPE_NAMES = {'string', 'number', 'integer', 'boolean', 'object', 'array', 'null'}
NS = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
F = FormatChecker()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def semantic_errors(catalog: dict, base: dict) -> list[str]:
    errors = []
    event_ids = [e['event_id'] for e in catalog['events']]
    expected = {e['id']: e for e in base['definitions']}
    if len(event_ids) != len(set(event_ids)):
        errors.append('Duplicate event_id')
    if set(event_ids) != set(expected):
        errors.append('Event coverage differs from the base catalog')
    sets = {s['set_id']: s for s in catalog['shared_property_sets']}
    if len(sets) != len(catalog['shared_property_sets']):
        errors.append('Duplicate property-set identifier')
    sources = {s['source_id']: s for s in catalog['sources']}
    if len(sources) != len(catalog['sources']):
        errors.append('Duplicate source identifier')
    own_nodes = [n for event in catalog['events'] for n in walk_nodes(event['properties'])]
    shared_nodes = [n for group in catalog['shared_property_sets'] for n in walk_nodes(group['properties'])]
    fields = [n for n in own_nodes + shared_nodes if n['structural_role'] == 'field']
    expected_counts = {
        'events': len(catalog['events']), 'shared_property_sets': len(sets), 'sources': len(sources),
        'event_owned_named_nodes': len(own_nodes), 'shared_named_nodes': len(shared_nodes),
        'event_specific_named_fields': sum(n['structural_role'] == 'field' for n in own_nodes),
        'shared_named_fields': sum(n['structural_role'] == 'field' for n in shared_nodes),
        'total_named_fields_excluding_composed_containers': len(fields),
        'known_type_named_fields': sum(n['type'] is not None for n in fields),
        'unknown_type_named_fields': sum(n['type'] is None for n in fields),
    }
    for key, value in expected_counts.items():
        if catalog['inventory'].get(key) != value:
            errors.append(f'Stale inventory count: {key}')
    for event in catalog['events']:
        eid = event['event_id']
        if eid not in expected:
            continue
        old = expected[eid]
        for actual, original in [('event_definition_version', 'definition_version'), ('catalog', 'catalog'),
                                 ('origin', 'origin'), ('technical_names', 'technical_names'), ('event_selector', 'match')]:
            if event[actual] != old[original]:
                errors.append(f'{eid}: changed base field {actual}')
        if len(event['property_set_refs']) != len(set(event['property_set_refs'])):
            errors.append(f'{eid}: duplicate property-set reference')
        if any(ref not in sets for ref in event['property_set_refs']):
            errors.append(f'{eid}: unresolved property-set reference')
    for owner in catalog['shared_property_sets'] + catalog['events']:
        owner_id = owner.get('event_id', owner.get('set_id'))
        nodes = list(walk_nodes(owner['properties'], include_items=True))
        paths = [n['path'] for n in nodes]
        if len(paths) != len(set(paths)):
            errors.append(f'{owner_id}: duplicate property path')
        for node in nodes:
            path = f'{owner_id}:{node["path"]}'
            known = node['type'] or []
            if any(t not in TYPE_NAMES for t in known):
                errors.append(f'{path}: invalid JSON type')
            if node['type'] == []:
                errors.append(f'{path}: empty types must use metadata null')
            if node['items'] is not None and known and 'array' not in known:
                errors.append(f'{path}: items on a non-array type')
            if node['properties'] and known and 'object' not in known:
                errors.append(f'{path}: object children on non-object type')
            if node['name'] != '[]' and node['path'].split('.')[-1] != node['name']:
                errors.append(f'{path}: name/path mismatch')
            location = node['path']
            if location.startswith('properties.') and node['scope'] != 'event_properties':
                errors.append(f'{path}: event property assigned to the wrong message scope')
            if (location == 'traits' or location.startswith('traits.') or location == 'context.traits'
                    or location.startswith('context.traits.')) and node['scope'] != 'traits':
                errors.append(f'{path}: trait assigned to the wrong message scope')
            for child in node['properties']:
                if child['path'] != node['path'] + '.' + child['name']:
                    errors.append(f'{path}: detached object child')
            if node['items'] and node['items']['path'] != node['path'] + '[]':
                errors.append(f'{path}: detached array item')
            ancestors = [node['path'][:m.end()] for m in re.finditer(r'\[\]', node['path'])]
            if ancestors != node['array_ancestors']:
                errors.append(f'{path}: incorrect array correlation scope')
            if node['provenance']['definition'] in {'documented', 'official_example'} and not node['sources']:
                errors.append(f'{path}: documentary provenance without a source')
            if node['provenance']['type'] == 'unknown' and known:
                errors.append(f'{path}: unknown type asserted as known')
            refs = node['sources'] + [s for e in node['provider_evidence'] for s in e['sources']]
            for src in refs:
                if src.get('source_id') not in sources or sources[src.get('source_id', '')]['url'] != src['url']:
                    errors.append(f'{path}: invalid source reference')
            all_evidence_types = set()
            if node['required'] in {'documented_required', 'documented_optional'} and not any(
                    e['required'] == node['required'] and e.get('sources')
                    for e in node['provider_evidence']):
                errors.append(f'{path}: required status lacks matching documentary evidence')
            if node['required'] == 'cdp_required' and not any(
                    e['provider'] == 'cdp' and e['required'] == 'cdp_required'
                    for e in node['provider_evidence']):
                errors.append(f'{path}: local required status lacks an explicit CDP contract')
            for ev in node['provider_evidence']:
                all_evidence_types.update(ev['types'])
                if ev['type_basis'] == 'unknown' and ev['types']:
                    errors.append(f'{path}: unknown evidence type asserted as known')
                if ev['type_basis'] in {'documented', 'official_example'} and not ev['sources']:
                    errors.append(f'{path}: type evidence missing sources')
                if ev['required'] == 'documented_required' and not ev['sources']:
                    errors.append(f'{path}: documented requirement missing sources')
                if ev['provider'] == 'cdp' and ev['type_basis'] == 'documented':
                    errors.append(f'{path}: CDP convention mislabeled as provider documentation')
            if all_evidence_types != set(known):
                errors.append(f'{path}: effective type differs from the full evidence union')
            if node['enum'] is not None and not node.get('enum_evidence'):
                errors.append(f'{path}: enum missing evidence metadata')
            if node['enum'] is not None and (node.get('enum_evidence') or {}).get('basis') == 'documented' and not node['enum_evidence'].get('sources'):
                errors.append(f'{path}: documented enum missing sources')
            for constraint in node['constraints']:
                if constraint.get('basis') == 'documented' and not constraint.get('sources'):
                    errors.append(f'{path}: documented constraint missing sources')
    return errors


def col_index(address: str) -> int:
    value = 0
    for ch in re.match(r'[A-Z]+', address).group(0):
        value = value * 26 + ord(ch) - 64
    return value - 1


def read_xlsx(path: Path) -> dict:
    result = {}
    with zipfile.ZipFile(path) as z:
        strings = []
        if 'xl/sharedStrings.xml' in z.namelist():
            root = ET.fromstring(z.read('xl/sharedStrings.xml'))
            strings = [''.join(t.text or '' for t in si.findall('.//s:t', NS)) for si in root.findall('s:si', NS)]
        wb = ET.fromstring(z.read('xl/workbook.xml'))
        rel = ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        links = {r.attrib['Id']: r.attrib['Target'] for r in rel}
        for sheet in wb.findall('s:sheets/s:sheet', NS):
            key = sheet.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']
            target = links[key]
            target = target.lstrip('/') if target.startswith('/') else 'xl/' + target
            xml = ET.fromstring(z.read(target))
            rows, formulas = {}, []
            for row in xml.findall('s:sheetData/s:row', NS):
                cells = {}
                for c in row.findall('s:c', NS):
                    address = c.attrib['r']
                    if c.find('s:f', NS) is not None:
                        formulas.append(address)
                    v = c.find('s:v', NS)
                    kind = c.get('t')
                    if kind == 's':
                        value = strings[int(v.text)] if v is not None else ''
                    elif kind == 'inlineStr':
                        value = ''.join(t.text or '' for t in c.findall('.//s:t', NS))
                    elif kind == 'b':
                        value = bool(int(v.text)) if v is not None else ''
                    else:
                        value = v.text if v is not None else ''
                    cells[col_index(address)] = value
                rows[int(row.get('r'))] = cells
            result[sheet.get('name')] = {'rows': rows, 'formulas': formulas,
                'panes': [p.attrib for p in xml.findall('s:sheetViews/s:sheetView/s:pane', NS)],
                'tables': len(xml.findall('s:tableParts/s:tablePart', NS))}
    return result


def set_pointer(obj, pointer, value, remove=False):
    parts = [p.replace('~1', '/').replace('~0', '~') for p in pointer.strip('/').split('/')]
    parent = obj
    for part in parts[:-1]:
        parent = parent[int(part)] if isinstance(parent, list) else parent[part]
    key = int(parts[-1]) if isinstance(parent, list) else parts[-1]
    if remove:
        del parent[key]
    else:
        parent[key] = value


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    root = args.directory.resolve()
    checks = []

    def check(identifier, category, operation):
        try:
            details = operation()
            checks.append({'id': identifier, 'category': category, 'status': 'passed', 'details': details})
        except Exception as exc:
            checks.append({'id': identifier, 'category': category, 'status': 'failed',
                           'error': f'{type(exc).__name__}: {exc}'})

    def demand(condition, message, details=None):
        if not condition:
            raise AssertionError(message)
        return details or message

    files = [p for p in root.rglob('*.json') if 'research' not in p.parts and p.name != 'validation-results.json']
    input_paths = files + [root / n for n in ['cdp-event-properties.csv', 'cdp-event-properties.xlsx',
        'generate_event_schemas.py', 'export_event_properties.py', 'validate_event_properties.py'] if (root / n).exists()]
    before = {str(p.relative_to(root)): sha(p) for p in input_paths}
    for path in sorted(files):
        check('json:' + str(path.relative_to(root)), 'json_syntax', lambda p=path: demand(strict_json(p) is not None, 'JSON parsed'))
    catalog = strict_json(root / 'cdp-event-properties.json')
    meta = strict_json(root / 'cdp-event-properties.schema.json')
    base = strict_json(root / catalog['base_catalog']['file'])
    generated = strict_json(root / 'cdp-event-payload-schemas.json')
    check('metadata-schema-valid', 'schema', lambda: Draft202012Validator.check_schema(meta))
    meta_validator = Draft202012Validator(meta, format_checker=F)
    check('metadata-catalog-valid', 'schema', lambda: meta_validator.validate(catalog))
    check('uri-format-checker-active', 'schema', lambda: demand('uri' in F.checkers and F.conforms('urn:cdp:event-properties:1', 'uri') and not F.conforms('not-a-uri', 'uri'), 'The URI checker is registered and rejects an invalid URI'))
    check('baseline-byte-identity', 'baseline', lambda: demand(sha(root / catalog['base_catalog']['file']) == BASE_SHA256 == catalog['base_catalog']['sha256'], 'The authoritative base catalog is byte-identical'))
    check('baseline-all-artifacts-unchanged', 'baseline', lambda: demand(all(sha(root / 'baseline' / name) == digest for name, digest in BASE_FILES.items()), 'All four baseline files, including compatibility bindings and schemas, are byte-identical'))
    check('baseline-catalog-schema', 'baseline', lambda: Draft202012Validator(strict_json(root / 'baseline/cdp-event-catalog.schema.json'), format_checker=F).validate(base))
    check('baseline-binding-schema', 'baseline', lambda: Draft202012Validator(strict_json(root / 'baseline/cdp-event-bindings.schema.json'), format_checker=F).validate(strict_json(root / 'baseline/cdp-event-bindings.json')))
    check('catalog-semantic-integrity', 'references', lambda: demand(not semantic_errors(catalog, base), '; '.join(semantic_errors(catalog, base)) or 'No semantic-integrity errors'))
    check('exact-102-event-coverage', 'coverage', lambda: demand(len(catalog['events']) == 102 and {e['event_id'] for e in catalog['events']} == {e['id'] for e in base['definitions']}, 'All 102 base events covered exactly'))
    check('base-category-counts-preserved', 'coverage', lambda: demand(Counter(e['catalog'] for e in catalog['events']) == Counter(e['catalog'] for e in base['definitions']), 'Primary catalog membership is unchanged'))
    expected = build_collection(catalog, 'documented', sha(root / 'cdp-event-properties.json'))
    check('generated-schema-exact-derivation', 'generation', lambda: demand(generated == expected, 'Generated schema collection equals a fresh derivation from the sole metadata authority'))
    candidate = build_collection(catalog, 'catalog_contract', sha(root / 'cdp-event-properties.json'))
    check('candidate-profile-schema-valid', 'generation', lambda: [Draft202012Validator.check_schema(x['schema']) for x in candidate['schemas']] and 'All candidate schemas are valid Draft 2020-12')
    schemas = {r['event_id']: r['schema'] for r in generated['schemas']}
    candidate_schemas = {r['event_id']: r['schema'] for r in candidate['schemas']}
    for eid, schema in schemas.items():
        check('payload-schema:' + eid, 'schema', lambda s=schema: Draft202012Validator.check_schema(s))
    check('schema-count-and-ids', 'coverage', lambda: demand(len(generated['schemas']) == 102 and len(schemas) == 102 and set(schemas) == {e['event_id'] for e in catalog['events']}, '102 distinct payload schemas with valid event references'))
    all_nodes = [n for owner in catalog['shared_property_sets'] + catalog['events'] for n in walk_nodes(owner['properties'], True)]
    check('source-registry-unique', 'provenance', lambda: demand(len({s['source_id'] for s in catalog['sources']}) == len(catalog['sources']), 'Source identifiers unique'))
    check('property-descriptions-present', 'descriptions', lambda: demand(catalog['description_language'] == 'en' and all(len(n['description'].strip()) >= 15 for n in all_nodes), 'English-language declaration and nonempty descriptions; semantic language review is documented separately'))
    audit = strict_json(root / 'description-audit.json')
    check('description-audit-exact-input', 'descriptions', lambda: demand(audit['audited_catalog']['sha256'] == sha(root / 'cdp-event-properties.json'), 'The editorial and phrase-overlap audit refers to the exact delivered catalog'))
    check('description-audit-full-node-coverage', 'descriptions', lambda: demand(audit['counts']['property_node_description_occurrences'] == len(all_nodes) and audit['counts']['by_structural_role'] == dict(Counter(n['structural_role'] for n in all_nodes)), 'The recorded audit covers every named property, composed container and array item'))
    check('no-invented-payload-limits', 'constraints', lambda: demand(all(not n['constraints'] or all(c.get('sources') for c in n['constraints']) for n in all_nodes), 'Every explicit payload constraint has evidence'))
    check('open-custom-property-policy', 'constraints', lambda: demand(all(n['additional_properties_allowed'] is True for n in all_nodes), 'Custom object fields remain allowed at every metadata node'))

    payload_cases = strict_json(root / 'fixtures/payload-cases.json')['cases']
    for case in payload_cases:
        target = schemas if case.get('profile', 'documented') == 'documented' else candidate_schemas
        def run(case=case, target=target):
            errors = list(Draft202012Validator(target[case['event_id']], format_checker=F).iter_errors(case['payload']))
            valid = not errors
            return demand(valid == case['valid'], f"Expected valid={case['valid']}; errors={[e.message for e in errors][:4]}", case['purpose'])
        check('payload:' + case['id'], 'payload_fixture', run)

    for case in strict_json(root / 'fixtures/metadata-negative-cases.json')['cases']:
        def run(case=case):
            changed = copy.deepcopy(catalog)
            set_pointer(changed, case['pointer'], case.get('value'), case.get('operation') == 'remove')
            errors = list(meta_validator.iter_errors(changed))
            if not errors:
                errors = semantic_errors(changed, base)
            return demand(bool(errors), 'Invalid metadata unexpectedly accepted', case['purpose'])
        check('negative-metadata:' + case['id'], 'negative_fixture', run)

    for case in strict_json(root / 'fixtures/array-correlation-cases.json')['cases']:
        def run(case=case):
            schema = {'allOf': [schemas['commerce.order_completed'], case['condition_schema']]}
            valid = Draft202012Validator(schema).is_valid(case['payload'])
            return demand(valid == case['valid'], 'Same-item condition returned the wrong result', case['purpose'])
        check('same-array-item:' + case['id'], 'array_structure', run)

    raw_cases = strict_json(root / 'fixtures/json-syntax-cases.json')['cases']
    for case in raw_cases:
        def run(case=case):
            duplicate = False
            def pairs(items):
                nonlocal duplicate
                keys = [k for k, _ in items]
                duplicate |= len(keys) != len(set(keys))
                return dict(items)
            ok = True
            try:
                json.loads(case['text'], object_pairs_hook=pairs,
                           parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
                ok = not duplicate
            except (ValueError, json.JSONDecodeError):
                ok = False
            return demand(ok == case['valid'], 'Strict JSON expectation failed', case['purpose'])
        check('syntax-fixture:' + case['id'], 'json_syntax', run)

    rows = export_rows(catalog)
    check('csv-byte-for-byte-derivation', 'exports', lambda: demand((root / 'cdp-event-properties.csv').read_bytes() == csv_bytes(catalog), 'CSV is exactly derived from the delivered metadata'))
    with (root / 'cdp-event-properties.csv').open(encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        headers, loaded_rows = reader.fieldnames, list(reader)
    check('csv-columns-and-rows', 'exports', lambda: demand(headers == COLUMNS and loaded_rows == rows, 'Every CSV cell agrees with the resolved metadata', {'rows': len(rows), 'columns': len(COLUMNS)}))
    xlsx = read_xlsx(root / 'cdp-event-properties.xlsx')
    def workbook_cells():
        sheet = xlsx['Properties']
        if [sheet['rows'].get(5, {}).get(j, '') for j in range(len(COLUMNS))] != COLUMNS:
            raise AssertionError('Excel property headers differ from CSV headers')
        observed = [[sheet['rows'].get(6+i, {}).get(j, '') for j in range(len(COLUMNS))] for i in range(len(rows))]
        desired = [[row[c] for c in COLUMNS] for row in rows]
        if observed != desired:
            for i, (a, b) in enumerate(zip(observed, desired), 6):
                if a != b:
                    raise AssertionError(f'Excel/JSON mismatch in row {i}')
        return {'rows': len(rows), 'cells_compared': len(rows) * len(COLUMNS)}
    check('xlsx-every-property-cell', 'exports', workbook_cells)
    def workbook_event_cells():
        sheet = xlsx['Events']
        counts = Counter(row['event_id'] for row in rows)
        compact = lambda v: json.dumps(v, ensure_ascii=False, separators=(',', ':'))
        for i, event in enumerate(catalog['events'], 6):
            desired = [event['event_id'], compact(event['technical_names']), event['message_type'],
                event['catalog'], event['origin'], event['schema_completeness'], str(counts[event['event_id']]),
                ', '.join(event['property_set_refs']), event['coverage'] if isinstance(event['coverage'], str) else compact(event['coverage'])]
            observed = [sheet['rows'].get(i, {}).get(j, '') for j in range(9)]
            if observed != desired:
                raise AssertionError(f'Excel/JSON event-coverage mismatch in row {i}')
        return {'rows': len(catalog['events']), 'cells_compared': 9 * len(catalog['events'])}
    check('xlsx-every-event-coverage-cell', 'exports', workbook_event_cells)
    check('xlsx-filter-and-freeze', 'exports', lambda: demand(xlsx['Properties']['tables'] > 0 and bool(xlsx['Properties']['panes']), 'Native table and frozen panes are present'))
    check('xlsx-literal-reference-data', 'exports', lambda: demand(not any(s['formulas'] for s in xlsx.values()), 'Reference text is stored as data, with no accidental formulas'))
    check('input-files-unchanged', 'integrity', lambda: demand(before == {str(p.relative_to(root)): sha(p) for p in input_paths}, 'Validation did not modify any input artifact'))
    summary = {'checks_executed': len(checks), 'checks_passed': sum(c['status'] == 'passed' for c in checks),
               'checks_failed': sum(c['status'] == 'failed' for c in checks)}
    result = {
        'status': 'passed' if not summary['checks_failed'] else 'failed',
        'generated_at_utc': datetime.now(timezone.utc).isoformat(),
        'runtime': {'python': platform.python_version(), 'jsonschema': version('jsonschema')},
        'summary': summary, 'inventory': catalog['inventory'],
        'fixture_counts': {'payload': len(payload_cases),
                           'metadata_negative': len(strict_json(root / 'fixtures/metadata-negative-cases.json')['cases']),
                           'same_array_item': len(strict_json(root / 'fixtures/array-correlation-cases.json')['cases']),
                           'strict_json': len(raw_cases)},
        'input_sha256': before, 'checks': checks,
        'limitations': [
            'No live CDP, Segment/RudderStack SDK, destination, or MCP service is called by this validator.',
            'Documentary completeness and semantic accuracy require source review; offline checks verify the captured evidence and artifacts.',
            'Descriptions were authored in English. A language declaration or phrase-overlap scan alone cannot prove semantic accuracy or legal originality.',
            'The default schema is deliberately partial. Example-only and CDP-proposed types are annotations until the catalog_contract profile is selected.',
            'Event selection remains the unchanged base matcher. Cross-field and destination-specific requirements are not silently made universal.',
        ],
    }
    (root / 'validation-results.json').write_bytes(canonical_bytes(result))
    lines = ['# Validazione delle proprietà degli eventi CDP', '',
             f"**Esito: {result['status'].upper()}.** {summary['checks_executed']} controlli eseguiti, {summary['checks_passed']} superati, {summary['checks_failed']} falliti.", '',
             f"Esecuzione UTC: {result['generated_at_utc']}. Python {result['runtime']['python']}; jsonschema {result['runtime']['jsonschema']}.", '',
             '## Copertura effettiva', '',
             f"- Eventi: **{len(catalog['events'])}**, con ID, versione, classificazione e matcher confrontati con il catalogo v1.1.0.",
             f"- Campi nominati: **{catalog['inventory']['total_named_fields_excluding_composed_containers']}**, di cui **{catalog['inventory']['event_specific_named_fields']}** specifici degli eventi e **{catalog['inventory']['shared_named_fields']}** condivisi.",
             f"- Container strutturali nominati aggiunti per comporre i percorsi: **{catalog['inventory']['composed_container_nodes']}**. Tipi non determinabili: **{catalog['inventory']['unknown_type_named_fields']}**.",
             f"- Righe di proprietà risolte per evento, inclusi i campi condivisi: **{len(rows)}**.",
             '- Schemi payload consegnati: **102**. Verificato anche il profilo alternativo catalog_contract generato in memoria.',
             f"- Celle Excel confrontate con i valori derivati dal JSON: **{len(rows) * len(COLUMNS)}** nel foglio Properties e **{9 * len(catalog['events'])}** nel foglio Events.",
             f"- Audit descrizioni collegato allo stesso hash: **{audit['counts']['property_node_description_occurrences']}** nodi. Il validatore controlla collegamento e copertura; non riesegue il confronto con le pagine web.", '',
             '## Controlli eseguiti', '', '| Categoria | Eseguiti | Superati | Falliti |', '|---|---:|---:|---:|']
    for category in sorted({c['category'] for c in checks}):
        group = [c for c in checks if c['category'] == category]
        passed = sum(c['status'] == 'passed' for c in group)
        lines.append(f'| {category} | {len(group)} | {passed} | {len(group)-passed} |')
    lines += ['', '## Anomalie', '']
    failures = [c for c in checks if c['status'] == 'failed']
    lines += [f"- `{c['id']}`: {c['error']}" for c in failures] or ['Nessun errore rilevato dai controlli eseguiti.']
    lines += ['', '## Riproduzione', '', '```bash', 'python -m pip install -r requirements.txt',
              'python generate_event_schemas.py', 'python export_event_properties.py',
              'python validate_event_properties.py', '```', '',
              'Il validatore legge gli input senza modificarli e aggiorna soltanto i due rapporti. Exit code 0 indica che tutti i controlli sono passati; 1 indica almeno un errore.', '',
              '## Limiti', '']
    lines += ['- ' + s for s in result['limitations']]
    lines += ['', 'La revisione delle fonti, le contraddizioni documentali e il controllo delle descrizioni sono descritti in `event-properties-research.md`. I singoli esiti e gli hash degli input sono in `validation-results.json`.', '']
    (root / 'validation-report.md').write_text('\n'.join(lines), encoding='utf-8')
    print(json.dumps({'status': result['status'], **summary}, ensure_ascii=False))
    if failures:
        print(json.dumps(failures, ensure_ascii=False, indent=2))
    return 0 if not summary['checks_failed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
