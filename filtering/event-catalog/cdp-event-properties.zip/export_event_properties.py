#!/usr/bin/env python3
"""Export one CSV row per resolved, named event property, including nesting."""
from __future__ import annotations
import argparse
import csv
import io
import json
from pathlib import Path
from generate_event_schemas import strict_json, expand_event, walk_nodes

COLUMNS = [
    'event_id', 'property_path', 'json_types', 'description_en', 'required', 'scope',
    'technical_event_names', 'message_type', 'catalog', 'property_name',
    'definition_provenance', 'type_provenance', 'provider_types',
    'provider_required', 'source_urls', 'source_sections', 'enum',
    'array_scopes', 'declared_in', 'notes',
]


def text_json(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'))


def export_rows(catalog: dict) -> list[dict]:
    sets = {s['set_id']: s for s in catalog['shared_property_sets']}
    rows = []
    for event in catalog['events']:
        owners = {}
        for ref in event['property_set_refs']:
            for node in walk_nodes(sets[ref]['properties']):
                owners.setdefault(node['path'], []).append('set:' + ref)
        for node in walk_nodes(event['properties']):
            owners.setdefault(node['path'], []).append('event:' + event['event_id'])
        for node in walk_nodes(expand_event(catalog, event)):
            pe = node['provider_evidence']
            rows.append({
                'event_id': event['event_id'],
                'technical_event_names': text_json(event['technical_names']),
                'message_type': event['message_type'], 'catalog': event['catalog'],
                'scope': node['scope'], 'property_path': node['path'], 'property_name': node['name'],
                'json_types': text_json(node['type']) if node['type'] is not None else 'unknown',
                'description_en': node['description'], 'required': node['required'],
                'definition_provenance': node['provenance']['definition'],
                'type_provenance': node['provenance']['type'],
                'provider_types': ' | '.join(dict.fromkeys(f"{e['provider']}:{','.join(e['types']) or 'unknown'} ({e['type_basis']}; {e.get('contract_scope','event')})" for e in pe)),
                'provider_required': ' | '.join(dict.fromkeys(f"{e['provider']}:{e['required']}" for e in pe)),
                'source_urls': ' | '.join(dict.fromkeys(s['url'] for s in node['sources'])),
                'source_sections': ' | '.join(dict.fromkeys(s['section'] for s in node['sources'])),
                'enum': text_json(node['enum']),
                'array_scopes': text_json(node['array_ancestors']),
                'declared_in': ' | '.join(owners.get(node['path'], [])),
                'notes': ' | '.join(node['notes']),
            })
    return rows


def csv_bytes(catalog: dict) -> bytes:
    stream = io.StringIO(newline='')
    writer = csv.DictWriter(stream, fieldnames=COLUMNS, lineterminator='\n')
    writer.writeheader()
    writer.writerows(export_rows(catalog))
    return ('\ufeff' + stream.getvalue()).encode('utf-8')


def main() -> int:
    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, default=here / 'cdp-event-properties.json')
    parser.add_argument('--output', type=Path, default=here / 'cdp-event-properties.csv')
    parser.add_argument('--json-rows', type=Path)
    args = parser.parse_args()
    catalog = strict_json(args.input)
    rows = export_rows(catalog)
    args.output.write_bytes(csv_bytes(catalog))
    if args.json_rows:
        args.json_rows.write_text(json.dumps({'columns': COLUMNS, 'rows': rows}, ensure_ascii=False))
    print(json.dumps({'output': str(args.output.resolve()), 'rows': len(rows), 'columns': len(COLUMNS)}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
