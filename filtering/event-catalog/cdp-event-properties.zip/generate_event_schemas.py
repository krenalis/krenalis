#!/usr/bin/env python3
"""Generate Draft 2020-12 payload schemas from cdp-event-properties.json.

No network access and no dependency other than Python's standard library.
The default 'documented' profile does not turn example-only types or CDP
suggestions into mandatory validation rules. 'catalog_contract' opts into
those candidate types. Neither profile closes an extensible object.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path
from typing import Any, Iterator

DRAFT = "https://json-schema.org/draft/2020-12/schema"
PROFILES = ("documented", "catalog_contract")
JSON_TYPES = ("string", "number", "integer", "boolean", "object", "array", "null")


def strict_json(path: Path) -> Any:
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError(f"Duplicate JSON key: {key}")
            result[key] = value
        return result

    def constant(value):
        raise ValueError(f"Non-JSON numeric constant: {value}")

    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=pairs,
                      parse_constant=constant)


def canonical_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")


def unique(items: list[Any]) -> list[Any]:
    output, seen = [], set()
    for item in items:
        key = json.dumps(item, sort_keys=True, ensure_ascii=False)
        if key not in seen:
            output.append(copy.deepcopy(item))
            seen.add(key)
    return output


def walk_nodes(nodes: list[dict], include_items: bool = False) -> Iterator[dict]:
    """Visit actual named properties; optionally visit anonymous array items."""
    for node in nodes:
        yield node
        yield from walk_nodes(node.get("properties", []), include_items)
        item = node.get("items")
        if item:
            if include_items:
                yield item
            yield from walk_nodes(item.get("properties", []), include_items)
            # Nested arrays have an anonymous item node of their own.
            nested = item.get("items")
            while nested:
                if include_items:
                    yield nested
                yield from walk_nodes(nested.get("properties", []), include_items)
                nested = nested.get("items")


def _merge_node(base: dict, specific: dict) -> dict:
    """Merge shared fields with a contextual description from the event.

    Conflicting evidence is retained. Event-specific names/meanings take
    precedence, while known type alternatives and sources are not discarded.
    """
    result = copy.deepcopy(base)
    for key, value in specific.items():
        if key not in {"properties", "items", "type", "sources", "provider_evidence", "notes"}:
            if specific.get("structural_role") == "structural_container" and base.get("structural_role") == "field":
                continue
            result[key] = copy.deepcopy(value)
    kinds = unique((base.get("type") or []) + (specific.get("type") or []))
    result["type"] = kinds or None
    for key in ("sources", "provider_evidence", "notes"):
        result[key] = unique(base.get(key, []) + specific.get(key, []))
    result["properties"] = merge_node_lists(base.get("properties", []), specific.get("properties", []))
    if base.get("items") and specific.get("items"):
        result["items"] = _merge_node(base["items"], specific["items"])
    else:
        result["items"] = copy.deepcopy(specific.get("items") or base.get("items"))
    return result


def merge_node_lists(base: list[dict], specific: list[dict]) -> list[dict]:
    output = {n["name"]: copy.deepcopy(n) for n in base}
    for node in specific:
        if node["name"] in output:
            output[node["name"]] = _merge_node(output[node["name"]], node)
        else:
            output[node["name"]] = copy.deepcopy(node)
    return list(output.values())


def expand_event(catalog: dict, event: dict) -> list[dict]:
    sets = {s["set_id"]: s for s in catalog["shared_property_sets"]}
    result = []
    for ref in event["property_set_refs"]:
        if ref not in sets:
            raise ValueError(f"Unknown property set {ref!r} for {event['event_id']}")
        result = merge_node_lists(result, sets[ref]["properties"])
    return merge_node_lists(result, event["properties"])


def evidence_applies(evidence: dict) -> bool:
    """Destination-only requirements never become universal event contracts."""
    return evidence.get("contract_scope", "event") in {
        "event", "message", "protocol", "general", "universal", "all", "cdp_contract", "cdp_proposed",
        "ecommerce_spec", "track_spec", "track_spec_example", "ruby_sdk_example",
        "semantic_spec", "b2b_saas_spec", "wire_payload",
    }


def selected_types(node: dict, profile: str) -> list[str]:
    evidence = [e for e in node.get("provider_evidence", []) if evidence_applies(e)]
    if profile == "catalog_contract":
        return unique([t for e in evidence if e.get("type_basis") in {"documented", "official_example", "cdp_proposed"}
                       for t in e.get("types", [])])
    # A generic declaration that leaves this value's type unspecified is
    # different from a provider that does not mention the field at all.
    # In particular, Array without an item contract must not silently become
    # Array[String] merely because another provider documents string items.
    if any(e.get("presence") == "documented" and e.get("type_basis") == "unknown"
           for e in evidence):
        return []
    documented = [e for e in evidence if e.get("type_basis") == "documented" and e.get("types")]
    if not documented:
        return []
    # Official examples can widen an explicit declaration that they contradict.
    # They cannot, alone, establish a restrictive type in the default profile.
    result = []
    for item in evidence:
        if item.get("type_basis") in {"documented", "official_example"}:
            result.extend(item.get("types", []))
    return unique(result)


def is_required(node: dict, profile: str) -> bool:
    if profile == "catalog_contract" and node["required"] == "cdp_required":
        return True
    evidence = [e for e in node.get("provider_evidence", [])
                if evidence_applies(e) and e.get("provider") in {"segment", "rudderstack"}]
    # A portable schema requires a field only when both providers explicitly
    # require it. Missing evidence, conditional/implicit generation, and an
    # explicit optional statement do not meet this criterion.
    return all(any(e["provider"] == provider and e.get("required") == "documented_required"
                   for e in evidence)
               and not any(e["provider"] == provider and e.get("required") == "documented_optional"
                           for e in evidence)
               for provider in ("segment", "rudderstack"))


def node_schema(node: dict, profile: str) -> dict:
    result = {
        "description": node["description"],
        "x-cdp-path": node["path"],
        "x-cdp-scope": node["scope"],
        "x-cdp-provenance": copy.deepcopy(node["provenance"]),
        "x-cdp-known-types": copy.deepcopy(node["type"]),
        "x-cdp-required-status": node["required"],
        "x-cdp-sources": copy.deepcopy(node["sources"]),
    }
    kinds = selected_types(node, profile)
    if kinds:
        result["type"] = kinds[0] if len(kinds) == 1 else kinds
    else:
        result["x-cdp-type-validation"] = "unconstrained"
    if node.get("enum") is not None:
        constraint = node.get("enum_evidence") or {}
        if constraint.get("basis") == "documented" and constraint.get("scope", "event") == "event":
            result["enum"] = copy.deepcopy(node["enum"])
        else:
            result["x-cdp-candidate-enum"] = copy.deepcopy(node["enum"])
    if node.get("properties") or "object" in (node.get("type") or []):
        result["properties"] = {n["name"]: node_schema(n, profile) for n in node["properties"]}
        result["additionalProperties"] = True
        required = [n["name"] for n in node["properties"] if is_required(n, profile)]
        if required:
            result["required"] = required
    if node.get("items"):
        result["items"] = node_schema(node["items"], profile)
    elif "array" in (node.get("type") or []):
        result["items"] = {}
    # No pattern/format/minimum/cardinality is inferred from a name or sample.
    for constraint in node.get("constraints", []):
        if constraint.get("basis") == "documented" and constraint.get("scope", "event") == "event":
            result[constraint["keyword"]] = copy.deepcopy(constraint["value"])
    return result


def build_collection(catalog: dict, profile: str = "documented", source_sha256: str | None = None) -> dict:
    if profile not in PROFILES:
        raise ValueError(f"Unknown profile: {profile}")
    records = []
    for event in catalog["events"]:
        nodes = expand_event(catalog, event)
        schema = {
            "$schema": DRAFT,
            "$id": f"urn:cdp:event-payload:{event['event_id']}:{catalog['version']}:{profile}",
            "title": f"{event['event_id']} payload",
            "description": "An open payload schema generated from the documented property catalog. Event selection is a separate operation.",
            "type": "object",
            "properties": {n["name"]: node_schema(n, profile) for n in nodes},
            "additionalProperties": True,
            "x-cdp-event-id": event["event_id"],
            "x-cdp-definition-version": event["event_definition_version"],
            "x-cdp-generation-profile": profile,
            "x-cdp-schema-completeness": event["schema_completeness"],
            "x-cdp-event-selector": copy.deepcopy(event["event_selector"]),
            "x-cdp-limitations": [
                "Event selection uses the unchanged base-catalog matcher; this schema does not replace that matcher.",
                "A valid payload does not prove event instrumentation, identity resolution, or business correctness.",
                "Unspecified fields and additional properties remain allowed.",
                "Cross-field identity alternatives and SDK-generated fields remain annotations unless explicitly modeled as constraints.",
            ],
        }
        required = [n["name"] for n in nodes if is_required(n, profile)]
        if required:
            schema["required"] = required
        records.append({"event_id": event["event_id"], "schema": schema})
    return {
        "collection_version": catalog["version"],
        "base_catalog_version": catalog["base_catalog"]["version"],
        "source_file": "cdp-event-properties.json",
        "source_sha256": source_sha256,
        "generation_profile": profile,
        "schema_count": len(records),
        "schemas": records,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    here = Path(__file__).resolve().parent
    parser.add_argument("--input", type=Path, default=here / "cdp-event-properties.json")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--profile", choices=PROFILES, default="documented")
    args = parser.parse_args()
    if args.output is None:
        suffix = "" if args.profile == "documented" else ".catalog-contract"
        args.output = here / f"cdp-event-payload-schemas{suffix}.json"
    catalog = strict_json(args.input)
    result = build_collection(catalog, args.profile, hashlib.sha256(args.input.read_bytes()).hexdigest())
    args.output.write_bytes(canonical_bytes(result))
    print(json.dumps({"output": str(args.output.resolve()), "schemas": len(result["schemas"]),
                      "profile": args.profile, "source_sha256": result["source_sha256"]}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
