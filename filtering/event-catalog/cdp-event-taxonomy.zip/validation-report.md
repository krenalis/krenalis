# Rapporto di validazione del catalogo CDP

**Esito: SUPERATO.** 202 controlli realmente eseguiti: 202 superati, 0 falliti.

Esecuzione UTC: 2026-10-29T10:04:34.001064Z. Python 3.12.14; jsonschema 4.26.0; Draft 2020-12.

Il conteggio comprende controlli strutturali, riferimenti, fixture positive e negative e funzioni locali di riferimento. Non corrisponde a query eseguite su un backend di produzione.

## Inventario effettivo

| Gruppo | Definizioni |
|---|---:|
| general_website | 17 |
| ecommerce | 36 |
| optional_modules | 48 |
| historical_technical | 1 |

Totale definizioni: **102**. Binding separati: **16**.

| Provenienza | Definizioni |
|---|---:|
| A. Official standard | 71 |
| B. Official recommendation | 16 |
| C. CDP suggested | 14 |
| D. Historical / Legacy | 1 |

| Catalogo primario | Definizioni |
|---|---:|
| ecommerce | 36 |
| general_website | 17 |
| legacy.technical | 1 |
| optional.advanced_leads | 2 |
| optional.b2b_saas | 8 |
| optional.content | 5 |
| optional.email | 5 |
| optional.experimentation | 1 |
| optional.live_chat | 4 |
| optional.subscription | 4 |
| optional.technical | 2 |
| optional.video | 17 |

## Copertura dei 12 requisiti

Un controllo può coprire più requisiti; le righe non si sommano al totale.

| N. | Requisito | Eseguiti | Superati | Falliti |
|---:|---|---:|---:|---:|
| 1 | Validità sintattica dei file JSON | 13 | 13 | 0 |
| 2 | Conformità agli schemi JSON | 48 | 48 | 0 |
| 3 | Unicità degli identificatori | 5 | 5 | 0 |
| 4 | Conteggi e categorie | 16 | 16 | 0 |
| 5 | Integrità dei riferimenti | 43 | 43 | 0 |
| 6 | Struttura e operatori dei matcher | 48 | 48 | 0 |
| 7 | Campi assenti e nomi opzionali | 29 | 29 | 0 |
| 8 | Distinzione fra event e name | 24 | 24 | 0 |
| 9 | Alias disabilitati per impostazione predefinita | 47 | 47 | 0 |
| 10 | Validità degli esempi MCP | 68 | 68 | 0 |
| 11 | Coerenza temporale e cambi di ora legale | 86 | 86 | 0 |
| 12 | Condizioni negative e indeterminatezza | 68 | 68 | 0 |

## Recupero dei test precedenti

| Suite originale | Conservati | Adattati | Non recuperati |
|---|---:|---:|---:|
| catalog_55 | 46 | 9 | 0 |
| mcp_67 | 40 | 27 | 0 |

Nuovi controlli senza corrispondenza diretta nelle suite originali: **91**. La mappatura di ogni vecchio ID ai controlli effettivamente eseguiti è in `validation-results.json`, sezione `legacy_test_recovery`.

Tutti gli ID delle due suite originali hanno una corrispondenza eseguita; alcuni controlli condividono il nuovo test che li sostituisce.

## Anomalie e correzioni

Nessun errore rilevato nell’esecuzione indicata. Le correzioni progettuali rispetto al rapporto precedente sono elencate qui sotto.

- La revisione di riferimento conserva 102 concetti e 16 binding; i conteggi effettivi e l’esito del confronto con gli inventari originali sono riportati sopra. Il registro dei binding è ora un file separato.
- Versioni di catalogo, schemi e DSL portate a 1.1.0; definition_version resta 1 per tutte le definizioni.
- Il campo ambiguo observed_match è sostituito dalla presenza degli eventi osservati, dalla condizione soddisfatta sui dati disponibili e dalla conclusione true/false/unknown basata sui limiti di evidenza.
- La DSL distingue ore trascorse, giorni locali mobili, giorni locali completi e intervalli assoluti. I casi 23/25 ore e i bound locali ambigui o inesistenti sono fixture esplicite.
- Le suite originali 55 e 67 sono recuperate come inventario; test uniti o adattati sono mappati singolarmente. Il numero della nuova esecuzione è calcolato e non viene forzato a 122.
- Il vecchio validator MCP correggeva il JSON durante la validazione. Questa versione legge soltanto gli input e verifica che i loro hash restino invariati.
- URI, date e date-time sono ora verificati da checker effettivamente registrati tramite jsonschema[format], con fixture positive e negative.

## Formati, calendario e integrità

Checker registrati: `{"date": {"registered": true}, "date-time": {"registered": true}, "uri": {"registered": true}}`. La disponibilità viene verificata prima di accettare gli esiti dei formati; fixture errate devono essere respinte.

Base timezone: `tzdata 2025.2`. Le finestre sono ricalcolate indipendentemente dai bound consegnati.

Gli hash SHA-256 di tutti i JSON e fixture letti sono in `input_files` del rapporto JSON. Il controllo finale verifica che gli input non siano cambiati.

## Riproduzione

Richiede Python 3.10 o successivo. Dalla cartella degli artefatti:

```bash
python -m pip install -r requirements.txt
python validate_catalog.py
```

Il percorso degli input è risolto rispetto a `__file__`, quindi il comando funziona anche da un’altra directory. `--directory PATH` seleziona un’altra cartella con gli stessi file. Lo script aggiorna soltanto i due rapporti; restituisce exit code 0 se tutti i controlli passano, 1 se rileva errori.

## Limiti

- Nessun backend CDP, server MCP, SQL, SDK vendor o tenant reale è stato eseguito o contattato.
- Matcher, predicati, conteggi, logica ternaria, singoli anchor del carrello e risoluzione temporale sono implementazioni locali di riferimento limitate alle fixture dichiarate; non sono un motore completo della DSL.
- La validazione non dimostra copertura degli eventi reali, correttezza della strumentazione, disponibilità degli snapshot, identity resolution, autorizzazioni o finalizzazione degli eventi in ritardo.
- I contratti dei sei tool sono proposte applicative. Vengono controllate la coerenza logica e le query, non una negoziazione MCP tools/list o l’esecuzione dei tool.
- Le fonti non sono state nuovamente scaricate. Si controllano struttura, URI, provenienza dichiarata e completezza rispetto agli inventari della ricerca recuperati.
- Python 3.10+ è il requisito di sintassi e dipendenze; l’unico interprete realmente eseguito in questa sessione è quello registrato in runtime.
- Il risolutore temporale richiede offset noto, respinge -00:00 e secondi intercalari; le durate effettive si calcolano sempre in UTC. La base IANA è fornita dalla dipendenza tzdata registrata, non dal sistema operativo.
