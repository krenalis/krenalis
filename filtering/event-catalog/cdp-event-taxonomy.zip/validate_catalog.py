#!/usr/bin/env python3
"""Validate the delivered CDP artefacts without modifying any input.

Python 3.10+. Install requirements.txt in a virtual environment, then run:
    python validate_catalog.py
    python validate_catalog.py --directory /path/to/artefacts

This is an offline artefact validator with small, explicitly scoped reference
evaluators. It is not a production CDP query engine, MCP server, or vendor SDK.
Only validation-results.json and validation-report.md are written.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.metadata
import json
import math
import platform
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime, time, timedelta, timezone
from pathlib import Path
from urllib.parse import urldefrag, urlsplit
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError, reset_tzpath

VERSION = '1.1.0'
UTC = timezone.utc
UNKNOWN = 'unknown'
MISSING = object()
INPUT_NAMES = {
    'catalog': 'cdp-event-catalog.json',
    'catalog_schema': 'cdp-event-catalog.schema.json',
    'bindings': 'cdp-event-bindings.json',
    'bindings_schema': 'cdp-event-bindings.schema.json',
    'mcp': 'cdp-mcp-examples.json',
    'dsl_schema': 'cdp-filter-dsl.schema.json',
}
FIXTURE_NAMES = [
    'expected-catalog.json', 'matcher-cases.json', 'semantic-cases.json',
    'temporal-cases.json', 'negative-cases.json', 'legacy-test-inventory.json',
]
USER_REQUIREMENTS = {
    1: 'Validità sintattica dei file JSON',
    2: 'Conformità agli schemi JSON',
    3: 'Unicità degli identificatori',
    4: 'Conteggi e categorie',
    5: 'Integrità dei riferimenti',
    6: 'Struttura e operatori dei matcher',
    7: 'Campi assenti e nomi opzionali',
    8: 'Distinzione fra event e name',
    9: 'Alias disabilitati per impostazione predefinita',
    10: 'Validità degli esempi MCP',
    11: 'Coerenza temporale e cambi di ora legale',
    12: 'Condizioni negative e indeterminatezza',
}


def strict_json(raw):
    """Reject duplicate object keys and non-JSON NaN/Infinity extensions."""
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError('Duplicate JSON key: ' + key)
            result[key] = value
        return result
    def constant(value):
        raise ValueError('Non-JSON numeric constant: ' + value)
    return json.loads(raw.decode('utf-8'), object_pairs_hook=pairs, parse_constant=constant)


def sha256(raw):
    return hashlib.sha256(raw).hexdigest()


def walk(value):
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from walk(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk(child)


def lookup(payload, path):
    value = payload
    for part in path.split('.'):
        if not isinstance(value, dict) or part not in value:
            return MISSING
        value = value[part]
    return value


def matcher_matches(record, matcher):
    """Boolean OR returns one classification per record, not one per branch."""
    for branch in matcher['any_of']:
        matched = True
        for term in branch['all']:
            if term['op'] != 'eq':
                raise ValueError('Unsupported matcher operator: ' + term['op'])
            value = lookup(record, term['field'])
            if value is MISSING or type(value) is not type(term['value']) or value != term['value']:
                matched = False
                break
        if matched:
            return True
    return False


def match_values(matcher, field):
    return {term['value'] for branch in matcher['any_of'] for term in branch['all'] if term['field'] == field}


def tri_all(values):
    return False if any(v is False for v in values) else (UNKNOWN if UNKNOWN in values else True)


def tri_any(values):
    return True if any(v is True for v in values) else (UNKNOWN if UNKNOWN in values else False)


def tri_not(value):
    return UNKNOWN if value == UNKNOWN else not value


def compatible_values(a, b):
    # bool is deliberately excluded from the numeric family.
    return type(a) is type(b) or (type(a) in (int, float) and type(b) in (int, float))


def property_match(condition, payload):
    value = lookup(payload, condition['path'])
    if value is MISSING or value is None:
        return UNKNOWN
    if condition['op'] == 'any_element':
        if not isinstance(value, list):
            return UNKNOWN
        return tri_any([tri_all([property_match(c, item) for c in condition['where']]) for item in value])
    expected, op = condition['value'], condition['comparison']
    if op == 'in':
        if not isinstance(expected, list) or not expected:
            raise ValueError('in requires a non-empty array')
        return tri_any([value == item if compatible_values(value, item) else UNKNOWN for item in expected])
    if not compatible_values(value, expected):
        return UNKNOWN
    if op == 'eq':
        return value == expected
    if op in {'gte', 'gt', 'lte', 'lt'}:
        if type(value) not in (int, float) or type(expected) not in (int, float):
            return UNKNOWN
        return {'gte': value >= expected, 'gt': value > expected, 'lte': value <= expected, 'lt': value < expected}[op]
    raise ValueError('Unsupported property operator: ' + op)


def count_conclusion(lower, upper, op, threshold):
    upper = math.inf if upper is None else upper
    if type(lower) is not int or lower < 0 or upper < lower:
        raise ValueError('Invalid count bounds')
    if op == 'eq':
        return True if lower == upper == threshold else (False if threshold < lower or threshold > upper else UNKNOWN)
    if op == 'gte':
        return True if lower >= threshold else (False if upper < threshold else UNKNOWN)
    if op == 'gt':
        return True if lower > threshold else (False if upper <= threshold else UNKNOWN)
    if op == 'lte':
        return True if upper <= threshold else (False if lower > threshold else UNKNOWN)
    if op == 'lt':
        return True if upper < threshold else (False if lower >= threshold else UNKNOWN)
    raise ValueError('Unsupported count operator: ' + op)


def parse_datetime(value):
    # Deliberately use APIs available on Python 3.10; no implicit local timezone.
    pattern = r'^(\d{4})-(\d{2})-(\d{2})[Tt](\d{2}):(\d{2}):(\d{2})(?:\.(\d+))?([Zz]|[+-]\d{2}:\d{2})$'
    match = re.fullmatch(pattern, value) if isinstance(value, str) else None
    if not match:
        raise ValueError('DATETIME_REQUIRES_EXPLICIT_OFFSET')
    y, month, day, h, minute, second = map(int, match.groups()[:6])
    fraction, offset = match.groups()[6:]
    if offset == '-00:00':
        raise ValueError('UNKNOWN_OFFSET_NOT_ALLOWED')
    if offset.lower() == 'z':
        tz = UTC
    else:
        oh, om = map(int, offset[1:].split(':'))
        if oh > 23 or om > 59:
            raise ValueError('INVALID_OFFSET')
        tz = timezone((1 if offset[0] == '+' else -1) * timedelta(hours=oh, minutes=om))
    return datetime(y, month, day, h, minute, second, int(((fraction or '') + '000000')[:6]), tzinfo=tz)


def utc_string(value):
    return value.astimezone(UTC).isoformat().replace('+00:00', 'Z')


def validate_as_of(as_of, timezone_name):
    value = parse_datetime(as_of)
    zone = ZoneInfo(timezone_name)
    if value.utcoffset() != value.astimezone(zone).utcoffset():
        raise ValueError('AS_OF_OFFSET_TIMEZONE_MISMATCH')
    return value.astimezone(UTC), zone


def resolve_local(naive, zone, policy):
    """Resolve local wall time by round-tripping both folds through UTC."""
    candidates = {}
    for fold in (0, 1):
        candidate = naive.replace(tzinfo=zone, fold=fold)
        instant = candidate.astimezone(UTC)
        if instant.astimezone(zone).replace(tzinfo=None) == naive:
            candidates[instant] = candidate
    if not candidates:
        raise ValueError('LOCAL_TIME_NONEXISTENT')
    if len(candidates) == 1:
        return next(iter(candidates))
    if policy == 'reject':
        raise ValueError('LOCAL_TIME_AMBIGUOUS')
    if policy == 'earlier':
        return min(candidates)
    if policy == 'later':
        return max(candidates)
    raise ValueError('INVALID_AMBIGUITY_POLICY')


def resolve_window(spec, as_of, timezone_name):
    end_as_of, zone = validate_as_of(as_of, timezone_name)
    mode = spec['mode']
    if mode == 'elapsed_hours':
        start = end_as_of - timedelta(hours=spec['start_hours_before_as_of'])
        end = end_as_of - timedelta(hours=spec['end_hours_before_as_of'])
    elif mode in {'rolling_local_calendar_days', 'previous_complete_calendar_days'}:
        if spec['timezone'] != timezone_name:
            raise ValueError('SELECTOR_TIMEZONE_MISMATCH')
        if spec['nonexistent_local_time'] != 'reject':
            raise ValueError('INVALID_NONEXISTENT_TIME_POLICY')
        local_as_of = end_as_of.astimezone(zone)
        if mode == 'rolling_local_calendar_days':
            target = local_as_of.replace(tzinfo=None) - timedelta(days=spec['days'])
            start = resolve_local(target, zone, spec['ambiguous_local_time'])
            end = end_as_of
        else:
            end_local = datetime.combine(local_as_of.date(), time.min)
            start_local = end_local - timedelta(days=spec['days'])
            start = resolve_local(start_local, zone, spec['ambiguous_local_time'])
            end = resolve_local(end_local, zone, spec['ambiguous_local_time'])
    elif mode == 'absolute_interval':
        start, end = parse_datetime(spec['from']).astimezone(UTC), parse_datetime(spec['to']).astimezone(UTC)
    else:
        raise ValueError('UNKNOWN_TEMPORAL_MODE')
    if not start < end <= end_as_of:
        raise ValueError('INVALID_TIME_WINDOW')
    return {
        'from': utc_string(start), 'to': utc_string(end), 'bounds': '[from,to)',
        'derivation': {'as_of': as_of, 'timezone': timezone_name,
                       'from_local': start.astimezone(zone).isoformat(),
                       'to_local': end.astimezone(zone).isoformat(),
                       'elapsed_seconds': (end - start).total_seconds()},
    }


def query_semantic_errors(query, definitions, catalog_version, enabled_ids=None):
    errors = []
    if query.get('catalog_version') != catalog_version:
        errors.append('CATALOG_VERSION_MISMATCH')
    execution = query.get('execution', {})
    try:
        validate_as_of(execution['as_of'], execution['timezone'])
    except (ValueError, KeyError, ZoneInfoNotFoundError) as exc:
        errors.append(str(exc))
        return errors
    for node in walk(query.get('where', {})):
        if 'definition_id' not in node:
            continue
        definition = definitions.get(node['definition_id'])
        if definition is None:
            errors.append('UNKNOWN_DEFINITION')
        elif node.get('definition_version') != definition['definition_version']:
            errors.append('DEFINITION_VERSION_UNAVAILABLE')
        if enabled_ids is not None and node['definition_id'] not in enabled_ids:
            errors.append('EVENT_NOT_CONFIGURED')
        try:
            window = node['event_time']
            resolved = resolve_window(window['temporal_spec'], execution['as_of'], execution['timezone'])
            if window.get('bounds') != resolved['bounds'] or any(parse_datetime(window[k]) != parse_datetime(resolved[k]) for k in ('from', 'to')):
                errors.append('RESOLVED_WINDOW_MISMATCH')
            derivation = window.get('derivation', {})
            expected_derivation = resolved['derivation']
            same_derivation = all(derivation.get(k) == expected_derivation[k] for k in ('as_of', 'timezone', 'elapsed_seconds'))
            for key in ('from_local', 'to_local'):
                actual_time, expected_time = parse_datetime(derivation[key]), parse_datetime(expected_derivation[key])
                same_derivation = same_derivation and actual_time == expected_time and actual_time.utcoffset() == expected_time.utcoffset()
            if not same_derivation:
                errors.append('WINDOW_DERIVATION_MISMATCH')
        except (ValueError, KeyError, TypeError, ZoneInfoNotFoundError) as exc:
            errors.append(str(exc))
    for node in walk(query.get('where', {})):
        if node.get('op') != 'exists_without_followup':
            continue
        try:
            grace = node['observation_grace']
            cutoff = parse_datetime(execution['as_of']).astimezone(UTC) - timedelta(hours=grace['elapsed_hours'])
            anchor, followup = node['anchor']['event_time'], node['followup']['event_time']
            if parse_datetime(anchor['to']) != cutoff or parse_datetime(grace['anchor_upper_bound']) != cutoff or not grace['upper_bound_exclusive']:
                errors.append('GRACE_BOUND_MISMATCH')
            if parse_datetime(followup['from']) > parse_datetime(anchor['from']) or parse_datetime(followup['to']) != parse_datetime(execution['as_of']):
                errors.append('FOLLOWUP_WINDOW_INCOMPLETE')
        except (KeyError, ValueError, TypeError) as exc:
            errors.append(str(exc))
    return errors


class Run:
    def __init__(self, directory):
        self.directory = directory
        self.checks = []
        self.inputs = {}
        self.documents = {}
        self.fixtures = {}
        self.counts = {}
        self.completeness = {}
        self.formats = {}
        self.validators = {}
        self.recovery = []
        self.runtime = {'python': platform.python_version(), 'python_requirement': '>=3.10', 'python_3_10_runtime_executed': platform.python_version_tuple()[:2] == ('3', '10')}

    def check(self, check_id, passed, description, requirements=(), legacy=(), **details):
        entry = {'id': check_id, 'status': 'passed' if passed else 'failed',
                 'description': description, 'user_requirement_ids': list(requirements),
                 'legacy_test_refs': list(legacy)}
        if details:
            entry['details'] = details
        self.checks.append(entry)
        return bool(passed)

    def load(self):
        pairs = [(key, self.directory / name, False) for key, name in INPUT_NAMES.items()]
        pairs += [(name, self.directory / 'fixtures' / name, True) for name in FIXTURE_NAMES]
        ok = True
        for key, path, is_fixture in pairs:
            try:
                raw = path.read_bytes()
                self.inputs[path.relative_to(self.directory).as_posix()] = {'sha256': sha256(raw), 'bytes': len(raw)}
                value = strict_json(raw)
                (self.fixtures if is_fixture else self.documents)[key] = value
                self.check('json_' + key, True, 'Lettura JSON UTF-8, chiavi univoche e numeri JSON validi.', [1])
            except (OSError, ValueError, UnicodeError) as exc:
                self.check('json_' + key, False, 'File leggibile e JSON rigorosamente valido.', [1], error=str(exc))
                ok = False
        return ok

    def protect_inputs(self):
        changed = []
        for name, original in self.inputs.items():
            try:
                if sha256((self.directory / name).read_bytes()) != original['sha256']:
                    changed.append(name)
            except OSError:
                changed.append(name)
        self.check('inputs_unchanged', not changed, 'Nessun JSON o fixture di input è stato modificato durante la validazione.', [1],
                   ['catalog_55:input_unchanged_during_validation', 'mcp_67:seed_remained_byte_identical'], changed=changed)

    def phase(self, name, function):
        try:
            function(self)
        except Exception as exc:
            self.check('phase_error_' + name, False, 'Errore nella fase di validazione; i test successivi della fase non sono dichiarati eseguiti.', error_type=type(exc).__name__, error=str(exc))


def schema_checks(run):
    from jsonschema import Draft202012Validator, FormatChecker
    from referencing import Registry, Resource
    run.runtime['jsonschema'] = importlib.metadata.version('jsonschema')
    run.runtime['tzdata'] = importlib.metadata.version('tzdata')
    fc = FormatChecker()
    schema_keys = ['catalog_schema', 'bindings_schema', 'dsl_schema']
    registry = Registry()
    for key in schema_keys:
        schema = run.documents[key]
        resource = Resource.from_contents(schema)
        registry = registry.with_resource((run.directory / INPUT_NAMES[key]).as_uri(), resource)
        if '$id' in schema:
            registry = registry.with_resource(schema['$id'], resource)
        Draft202012Validator.check_schema(schema)
        legacy = ['catalog_55:draft_2020_12_metaschema'] if key == 'catalog_schema' else (['mcp_67:draft202012_schema_meta_validation'] if key == 'dsl_schema' else [])
        run.check('metaschema_' + key, True, 'Schema formalmente valido: Draft 2020-12.', [2], legacy)
    required_formats = sorted({node['format'] for key in schema_keys for node in walk(run.documents[key]) if 'format' in node})
    run.formats = {fmt: {'registered': fmt in fc.checkers} for fmt in required_formats}
    run.check('format_checkers_registered', all(v['registered'] for v in run.formats.values()), 'Tutti i formati richiesti dagli schemi hanno un checker effettivamente registrato.', [2, 11], formats=run.formats)
    for fmt, valid, invalid in [('date', '2026-10-29', '2026-02-30'), ('date-time', '2026-10-29T11:00:00Z', '2026-10-29T11:00:00'), ('uri', 'https://www.twilio.com/docs/segment', 'not a uri')]:
        passed = fmt in fc.checkers and fc.conforms(valid, fmt) and not fc.conforms(invalid, fmt)
        legacy = ['mcp_67:source_uri_negative_fixture_rejected'] if fmt == 'uri' else []
        run.check('format_positive_negative_' + fmt, passed, 'Il checker accetta il valore valido e respinge la fixture non valida.', [2, 11], legacy, format=fmt)
    for name, schema_key in [('catalog', 'catalog_schema'), ('bindings', 'bindings_schema')]:
        validator = Draft202012Validator(run.documents[schema_key], format_checker=fc, registry=registry)
        run.validators[name] = validator
        errors = [{'path': list(e.absolute_path), 'message': e.message} for e in validator.iter_errors(run.documents[name])]
        legacy = ['catalog_55:catalog_json_schema', 'mcp_67:seed_supplementary_source_uri_formats'] if name == 'catalog' else []
        run.check('schema_' + name, not errors, 'Artefatto conforme allo schema consegnato, con i formati registrati.', [2, 6], legacy, errors=errors[:30], error_count=len(errors))
    run.validators['query'] = Draft202012Validator(run.documents['dsl_schema'], format_checker=fc, registry=registry)


def catalog_checks(run):
    catalog, binding_doc = run.documents['catalog'], run.documents['bindings']
    defs, bindings = catalog['definitions'], binding_doc['bindings']
    by_id = {d['id']: d for d in defs}
    expected = run.fixtures['expected-catalog.json']
    ids = [d['id'] for d in defs] + [b['id'] for b in bindings]
    duplicate_ids = {k: v for k, v in Counter(ids).items() if v > 1}
    run.check('unique_ids', not duplicate_ids, 'ID univoci fra definizioni e binding.', [3], ['catalog_55:unique_ids'], duplicates=duplicate_ids)
    names = defaultdict(list)
    for d in defs:
        for name in d['technical_names']:
            names[name].append(d['id'])
    duplicates = {k: v for k, v in names.items() if len(v) > 1}
    run.check('unique_canonical_names', not duplicates, 'Una definizione per nome tecnico canonico; i cataloghi condividono l’ID.', [3, 4], ['catalog_55:unique_canonical_names'], duplicates=duplicates)
    binding_names = [b['technical_name'] for b in bindings]
    run.check('unique_binding_names', len(binding_names) == len(set(binding_names)), 'Nomi tecnici univoci nel registro varianti.', [3], ['catalog_55:unique_binding_names'])
    fields = set(expected['required_definition_fields'])
    invalid_fields = [d['id'] for d in defs if set(d) != fields]
    run.check('twenty_definition_fields', not invalid_fields, 'Ogni definizione contiene i 20 campi concordati, senza campi mancanti.', [2], invalid=invalid_fields)
    placeholders = []
    for d in defs:
        for key in ['id', 'display_name', 'description', 'category']:
            value = d.get(key)
            if not isinstance(value, str) or not value.strip() or re.fullmatch(r'(?i)(TODO|TBD|PLACEHOLDER|\.\.\.|…)', value.strip()):
                placeholders.append([d.get('id'), key])
    run.check('no_empty_or_placeholder_core_text', not placeholders, 'Campi testuali fondamentali compilati; non è una verifica automatica della qualità linguistica.', [2], invalid=placeholders)
    run.check('definition_versions_unchanged', all(d['definition_version'] == 1 for d in defs), 'Le 102 definizioni mantengono versione 1.', [5])
    run.check('catalog_schema_versions', catalog['schema_version'] == VERSION and catalog['catalog_version'] == VERSION, 'Catalogo e schema dati adottano versione 1.1.0.', [2, 5])
    invalid = [b['id'] for b in bindings if b['target_definition_id'] not in by_id or b['target_definition_version'] != by_id[b['target_definition_id']]['definition_version']]
    run.check('binding_references', not invalid, 'Ogni variante punta a una definizione e versione esistenti.', [5], ['catalog_55:binding_references'], invalid=invalid)
    run.check('binding_registry_separate', 'compatibility_bindings' not in catalog and catalog['bindings_reference']['file'] == INPUT_NAMES['bindings'] and catalog['bindings_reference']['schema'] == INPUT_NAMES['bindings_schema'] and catalog['bindings_reference']['binding_count'] == len(bindings), 'Il registro dei binding è separato e referenziato correttamente.', [5, 9])
    run.check('binding_registry_versions_and_inventory',
              binding_doc['schema_version'] == binding_doc['binding_registry_version'] == catalog['bindings_reference']['binding_registry_version'] == VERSION
              and binding_doc['catalog_reference'] == {'file': INPUT_NAMES['catalog'], 'catalog_version': catalog['catalog_version']}
              and binding_doc['inventory']['binding_count'] == len(bindings)
              and binding_doc['inventory']['counts_by_relation'] == dict(Counter(b['relation'] for b in bindings))
              and binding_doc['inventory']['default_enabled_count'] == sum(b['enabled_by_default'] for b in bindings),
              'Versioni, riferimento al catalogo e conteggi del registro separato coincidono con i record.', [4, 5, 9])
    invalid = [d['id'] for d in defs if match_values(d['match'], 'event') != set(d['technical_names'])]
    run.check('technical_names_matcher_consistency', not invalid, 'technical_names coincide esattamente con i nomi event del matcher.', [6, 8], ['catalog_55:technical_names_matcher_consistency'], invalid=invalid)
    invalid = [b['id'] for b in bindings if match_values(b['match'], 'event') != {b['technical_name']} or match_values(b['match'], 'type') != {b['event_type']}]
    run.check('binding_name_matcher_consistency', not invalid, 'Nome e tipo del binding coincidono con il matcher.', [6], ['catalog_55:binding_name_matcher_consistency'], invalid=invalid)
    invalid = [d['id'] for d in defs if match_values(d['match'], 'type') == {'track'} and any(p['path'] == 'name' for p in d['key_properties'])]
    run.check('track_property_namespace', not invalid, 'Il nome di prodotto/promozione è properties.name; il nome del track è event.', [8], ['catalog_55:track_property_namespace'], invalid=invalid)
    invalid = [d['id'] for d in defs if len(d['key_properties']) != len({p['path'] for p in d['key_properties']})]
    run.check('unique_property_paths', not invalid, 'Percorsi key_properties univoci per definizione.', [3], ['catalog_55:unique_property_paths'], invalid=invalid)
    membership = defaultdict(set)
    for d in defs:
        for cat in [d['catalog']] + d['related_catalogs']:
            membership[cat].add(d['id'])
    run.check('catalog_membership', dict(membership) == {k: set(v) for k, v in catalog['catalog_membership'].items()}, 'Gli indici dei cataloghi corrispondono alle definizioni condivise.', [4, 5], ['catalog_55:catalog_membership'])
    presets = set(catalog['default_presets']['general_website'] + catalog['default_presets']['ecommerce_addon'])
    enabled = {d['id'] for d in defs if d['enabled_by_default']}
    run.check('default_presets_consistency', presets == enabled, 'I preset coincidono con gli ID abilitati per default.', [4, 5], ['catalog_55:default_presets_consistency'])
    run.check('bindings_disabled_by_default', all(b['enabled_by_default'] is False and b['requires_admin_validation'] is True for b in bindings), 'Nessun alias o candidato è attivato senza verifica amministrativa.', [9], ['catalog_55:bindings_disabled_by_default'])
    # IDs for group/alias are read from their native type, avoiding an invented ID.
    native_results = {}
    for event_type in ('page', 'screen', 'identify', 'group', 'alias'):
        candidates = [d for d in defs if match_values(d['match'], 'type') == {event_type}]
        native_results[event_type] = len(candidates) == 1 and matcher_matches({'type': event_type}, candidates[0]['match'])
    run.check('native_types_without_name', all(native_results.values()), 'page/screen/identify/group/alias sono classificabili senza un nome track.', [6, 7, 8], results=native_results)
    official_invalid = []
    for d in defs:
        if d['origin'][0] not in {'A', 'B'}:
            continue
        urls = [d['source_url']] + [s['url'] for s in d['sources']]
        if not d['source_url'] or not d['sources'] or any(not u or not (urlsplit(u).hostname or '').endswith(('twilio.com', 'segment.com', 'rudderstack.com', 'rudderlabs.com')) for u in urls):
            official_invalid.append(d['id'])
    run.check('official_sources_for_A_B', not official_invalid, 'Le definizioni A e B indicano fonti dei provider ufficiali.', [2], invalid=official_invalid)
    sets = expected['sets']
    specifications = {
        'segment_ecommerce_v2': ('segment', 'Ecommerce Events', sets['ECOMMERCE']),
        'rudderstack_ecommerce_current': ('rudderstack', 'Ecommerce Events Specification', sets['ECOMMERCE']),
        'segment_b2b_saas': ('segment', 'B2B SaaS', sets['B2B']),
        'segment_video': ('segment', 'Video Spec', sets['VIDEO_COMMON'] + ['Video Playback Exited']),
        'rudderstack_video': ('rudderstack', 'Video Events Spec', sets['VIDEO_COMMON']),
        'segment_email': ('segment', 'Email Events', sets['EMAIL']),
        'segment_live_chat': ('segment', 'Live Chat Events', sets['CHAT']),
        'segment_ab_testing': ('segment', 'A/B Testing Events', ['Experiment Viewed']),
    }
    for key, (provider, spec, expected_names) in specifications.items():
        actual = {s['documented_name'] for d in defs for s in d['standard'] if s['provider'] == provider and s['specification'] == spec}
        target = set(expected_names)
        declaration = catalog['completeness'][key]
        good = actual == target and set(declaration['names']) == target and declaration['expected'] == len(target) and declaration['included'] == len(actual)
        details = {'expected': len(target), 'actual': len(actual), 'missing': sorted(target - actual), 'extra': sorted(actual - target)}
        run.completeness[key] = details
        run.check('complete_' + key, good, 'Nomi canonici confrontati con l’inventario indipendente della ricerca.', [4], ['catalog_55:complete_' + key], **details)
    legacy = [b for b in bindings if b['origin'].startswith('D.')]
    alias_map = {b['technical_name']: by_id[b['target_definition_id']]['technical_names'][0] for b in legacy if b['target_definition_id'] in by_id}
    run.check('complete_legacy_aliases', alias_map == expected['legacy_aliases'] and len(legacy) == 12, 'I 12 alias storici e le destinazioni coincidono con l’inventario verificato.', [4, 5, 9], ['catalog_55:complete_legacy_aliases'], mapping=alias_map)
    nonlegacy = set(binding_names) - set(alias_map)
    run.check('four_nonlegacy_variants', nonlegacy == {'User Signed Up', 'User Signed In', 'User Signed Out', 'Purchase Completed'}, 'Il registro contiene esattamente le tre varianti di autenticazione e il candidato acquisto.', [4, 9])
    registered = {s['url'] for s in catalog['source_registry']}
    urls = []
    for d in defs:
        urls.extend(([d['source_url']] if d['source_url'] else []) + [s['url'] for s in d['sources']] + [s['source_url'] for s in d['standard']] + [u for p in d['key_properties'] for u in p['source_urls']])
    for b in bindings:
        urls.extend(([b['source_url']] if b['source_url'] else []) + [s['url'] for s in b['sources']])
    missing = sorted({urldefrag(u).url for u in urls if urldefrag(u).url not in registered})
    run.check('source_registry_coverage', not missing, 'Tutte le fonti delle definizioni e dei binding compaiono nel registro fonti.', [5], ['catalog_55:source_registry_coverage'], missing=missing)
    counts = {'definitions': len(defs), 'bindings': len(bindings),
              'by_primary_catalog': dict(sorted(Counter(d['catalog'] for d in defs).items())),
              'by_origin': dict(sorted(Counter(d['origin'] for d in defs).items())),
              'bindings_by_origin': dict(sorted(Counter(b['origin'] for b in bindings).items())),
              'default_enabled_definitions': len(enabled),
              'by_requested_group': {'general_website': sum(d['catalog'] == 'general_website' for d in defs), 'ecommerce': sum(d['catalog'] == 'ecommerce' for d in defs), 'optional_modules': sum(d['catalog'].startswith('optional.') for d in defs), 'historical_technical': sum(d['catalog'] == 'legacy.technical' for d in defs)}}
    run.counts = counts
    expected_totals = expected['expected_totals']
    run.check('independent_expected_counts', all(counts[k] == v for k, v in expected_totals.items()), 'Conteggi reali confrontati con quelli richiesti: 102 definizioni e 16 binding.', [4], actual=counts)
    inventory = catalog['inventory']
    run.check('declared_counts', inventory['definition_count'] == len(defs) and inventory['counts_by_primary_catalog'] == counts['by_primary_catalog'] and inventory['counts_by_origin'] == counts['by_origin'] and inventory['default_enabled_count'] == len(enabled), 'L’inventario dichiarato coincide con i record effettivi.', [4], ['catalog_55:declared_counts'])


def matcher_checks(run):
    defs = {d['id']: d for d in run.documents['catalog']['definitions']}
    for case in run.fixtures['matcher-cases.json']['cases']:
        actual = matcher_matches(case['input'], defs[case['definition_id']]['match'])
        run.check('matcher_' + case['id'], actual is case['expected'], 'Fixture del matcher esatto: ' + case['id'] + '.', [6, 7, 8, 9],
                  ['catalog_55:matcher_' + case['id']], expected=case['expected'], actual=actual)
    original = defs['commerce.order_completed']['match']
    duplicated = {'any_of': copy.deepcopy(original['any_of'] * 2)}
    records = [{'type': 'track', 'event': 'Order Completed', 'messageId': 'm1'}]
    count = sum(1 for record in records if matcher_matches(record, duplicated))
    run.check('matcher_or_counts_record_once', count == 1, 'Due rami OR compatibili non duplicano lo stesso record.', [6], ['catalog_55:matcher_or_counts_record_once'], actual=count)
    binding = next(b for b in run.documents['bindings']['bindings'] if b['technical_name'] == 'Completed Order')
    union = {'any_of': original['any_of'] + binding['match']['any_of']}
    run.check('matcher_explicit_binding_union', matcher_matches({'type': 'track', 'event': 'Completed Order'}, union), 'L’unione esplicita del binding funziona soltanto nel matcher temporaneo di questa fixture.', [6, 9], ['catalog_55:matcher_explicit_binding_union'])


def mcp_checks(run):
    from jsonschema import Draft202012Validator, FormatChecker
    doc = run.documents['mcp']
    catalog = run.documents['catalog']
    defs = {d['id']: d for d in catalog['definitions']}
    examples = doc['examples']
    by_number = {e['example_id'][:2]: e for e in examples}
    execution = doc['illustrative_environment']['execution']
    unique_ids = {e['example_id'] for e in examples}
    run.check('example_ids_unique', len(unique_ids) == len(examples) == 9, 'Sono presenti nove esempi query con ID univoci.', [3, 10], ['mcp_67:example_ids_unique'])
    run.check('catalog_versions_match_seed', doc['catalog_reference']['catalog_version'] == catalog['catalog_version'] == VERSION and doc['dsl_version'] == VERSION and all(e['query']['catalog_version'] == VERSION and e['query']['dsl_version'] == VERSION for e in examples), 'Versioni di catalogo e DSL coerenti fra file ed esempi.', [5, 10], ['mcp_67:catalog_versions_match_seed'])
    if 'sha256' in doc['catalog_reference']:
        run.check('mcp_catalog_hash', doc['catalog_reference']['sha256'] == run.inputs[INPUT_NAMES['catalog']]['sha256'], 'L’hash del catalogo dichiarato dal MCP corrisponde al file consegnato.', [5, 10])
    all_semantic_errors = []
    for example in examples:
        errors = [{'path': list(e.absolute_path), 'message': e.message} for e in run.validators['query'].iter_errors(example['query'])]
        legacy = ['mcp_67:schema_' + example['example_id'], 'mcp_67:datetime_profile_' + example['example_id']]
        run.check('query_schema_' + example['example_id'], not errors, 'Query conforme alla DSL consegnata; i formati date-time sono attivi.', [2, 10, 11], legacy, errors=errors[:15])
        errors = query_semantic_errors(example['query'], defs, catalog['catalog_version'])
        all_semantic_errors.extend(errors)
        run.check('query_references_time_' + example['example_id'], not errors, 'Riferimenti, timezone, bound, derivazioni e grace coerenti.', [5, 10, 11], errors=errors)
    selectors = [node for example in examples for node in walk(example['query']['where']) if 'definition_id' in node]
    run.check('all_11_event_references_exist_at_exact_version', len(selectors) == 11 and all(s['definition_id'] in defs and s['definition_version'] == defs[s['definition_id']]['definition_version'] for s in selectors), 'Undici selettori puntano a ID e versioni reali.', [5, 10], ['mcp_67:all_11_event_references_exist_at_exact_version'])
    run.check('all_11_event_windows_valid', len(selectors) == 11 and not all_semantic_errors, 'Tutte le undici finestre sono state risolte e confrontate con il payload.', [11], ['mcp_67:all_11_event_windows_valid'])
    run.check('execution_fixture_consistent_in_9_examples', all(e['query']['execution'] == execution for e in examples), 'Gli esempi condividono il contesto dichiarato; la modalità temporale è per selettore.', [10, 11], ['mcp_67:execution_fixture_consistent_in_9_examples'])
    asof, zone = validate_as_of(execution['as_of'], execution['timezone'])
    run.check('as_of_timezone_offset_consistent', True, 'L’offset di as_of concorda con la timezone IANA.', [11], ['mcp_67:as_of_timezone_offset_consistent'])
    run.check('as_of_utc_consistent', asof == parse_datetime(doc['illustrative_environment']['as_of_utc']), 'Le rappresentazioni UTC e locale di as_of coincidono.', [11], ['mcp_67:as_of_utc_consistent'])
    observed_modes = {s['event_time']['temporal_spec']['mode'] for s in selectors}
    run.check('four_temporal_modes_demonstrated', observed_modes == {'elapsed_hours', 'rolling_local_calendar_days', 'previous_complete_calendar_days', 'absolute_interval'}, 'Gli esempi mostrano durata, giorni locali mobili, giorni completi e intervalli assoluti.', [10, 11], modes=sorted(observed_modes))
    for name, window in doc['illustrative_environment']['time_windows'].items():
        resolved = resolve_window(window['temporal_spec'], execution['as_of'], execution['timezone'])
        actual = {key: window[key] for key in ('from', 'to', 'bounds', 'derivation')}
        run.check('environment_window_' + name, actual == resolved, 'La finestra descrittiva è ricalcolabile dalla sua temporal_spec.', [11], expected=resolved, actual=actual)
    cart = by_number['03']['query']['where']
    cutoff = asof - timedelta(hours=24)
    run.check('cart_grace_24h_exclusive_and_exact', cart['observation_grace']['elapsed_hours'] == 24 and cart['observation_grace']['upper_bound_exclusive'] is True and parse_datetime(cart['anchor']['event_time']['to']) == parse_datetime(cart['observation_grace']['anchor_upper_bound']) == cutoff, 'La grace esclude gli anchor vecchi esattamente 24 ore.', [11, 12], ['mcp_67:cart_grace_24h_exclusive_and_exact'])
    run.check('cart_followup_window_and_correlation', cart['same_resolved_profile'] is True and cart['correlation'] == [{'anchor_path': 'properties.cart_id', 'followup_path': 'properties.cart_id', 'comparison': 'eq', 'on_missing': 'unknown'}] and parse_datetime(cart['followup']['event_time']['to']) == asof, 'Follow-up sullo stesso profilo e carrello, fino ad as_of.', [10, 11, 12], ['mcp_67:cart_followup_window_and_correlation'])
    run.check('cart_ordering_and_ties_explicit', cart['ordering'] == {'relation': 'strictly_after_anchor', 'same_timestamp': 'unknown_unless_source_order_resolves'}, 'L’ordine temporale e i pareggi sono espliciti.', [11, 12], ['mcp_67:cart_ordering_and_ties_explicit'])
    past, recent = by_number['05']['query']['where']['conditions']
    run.check('historical_and_recent_windows_contiguous', past['event']['event_time']['to'] == recent['event']['event_time']['from'] and parse_datetime(past['event']['event_time']['from']) == parse_datetime(doc['illustrative_environment']['available_history_start']), 'Presenza storica e assenza recente usano finestre contigue senza sovrapposizioni.', [11, 12], ['mcp_67:historical_and_recent_windows_contiguous'])
    run.check('login_and_identify_refs_remain_distinct', by_number['02']['query']['where']['event']['definition_id'] == 'auth.signed_in' and by_number['09']['query']['where']['event']['definition_id'] == 'identity.identified', 'identify non sostituisce il login.', [5, 10], ['mcp_67:login_and_identify_refs_remain_distinct'])
    run.check('page_name_is_root_name', by_number['08']['query']['where']['event']['where'][0]['path'] == 'name', 'Il nome della pagina è name alla radice.', [8, 10], ['mcp_67:page_name_is_root_name'])
    run.check('distinct_products_vs_event_instances', by_number['04']['query']['where']['measure'] == {'kind': 'distinct', 'path': 'properties.product_id', 'on_missing': 'unknown'} and by_number['06']['query']['where']['measure'] == {'kind': 'event_instances'}, 'Prodotti distinti e occorrenze di visualizzazione restano misure diverse.', [10, 12], ['mcp_67:distinct_products_vs_event_instances'])
    tools = doc['tool_contracts']
    tool_names = [t['name'] for t in tools]
    run.check('six_unique_read_only_proposed_tool_contracts', len(set(tool_names)) == len(tool_names) == 6 and all(t['access'] == 'read_only' and t['implementation_status'] == 'proposed_not_implemented' for t in tools), 'Sei contratti applicativi proposti, senza dichiararli API vendor esistenti.', [10], ['mcp_67:six_unique_read_only_proposed_tool_contracts'])
    listed = next(t for t in tools if t['name'] == 'cdp_events_list')
    validate = next(t for t in tools if t['name'] == 'cdp_profile_filters_validate')
    query = next(t for t in tools if t['name'] == 'cdp_profiles_query')
    run.check('execution_context_can_be_discovered', all(key in listed['output_contract'] for key in ('catalog_version', 'binding_set_id', 'binding_set_version', 'execution_defaults')), 'Il contratto espone versioni e contesto necessari per costruire le query.', [10], ['mcp_67:execution_context_can_be_discovered'])
    run.check('validate_to_query_compiled_id_contract', 'compiled_filter_id' in validate['output_contract'] and 'compiled_filter_id' in query['input_contract'], 'Il contratto query riceve il filtro compilato dal validatore.', [10], ['mcp_67:validate_to_query_compiled_id_contract'])
    fc = FormatChecker()
    run.check('mcp_source_note_urls_valid', all(fc.conforms(s['url'], 'uri') for s in doc['source_notes']), 'URI delle note di fonte formalmente validi; nessun fetch HTTP.', [2], ['mcp_67:mcp_source_note_urls_valid'])
    # Specific result payloads are checked against the schema's public $defs.
    result_schema = dict(run.documents['dsl_schema'])
    result_schema = {'$schema': result_schema['$schema'], '$defs': result_schema['$defs'], '$ref': '#/$defs/condition_evaluation_result'}
    result_validator = Draft202012Validator(result_schema, format_checker=fc)
    results = doc['result_contract_examples']
    run.check('four_result_contract_examples', len(results) == 4, 'Quattro risultati dimostrano osservazione, condizione e conclusione separatamente.', [10, 12])
    for index, result in enumerate(results):
        errors = [e.message for e in result_validator.iter_errors(result)]
        run.check('result_schema_' + str(index + 1), not errors, 'Risultato conforme alla definizione condition_evaluation_result.', [2, 10, 12], errors=errors)
        evidence = result['evidence']
        observed_bounds, bounds = evidence['observed_count_bounds'], evidence['count_bounds']
        pred = result['predicate']
        observed = count_conclusion(observed_bounds['lower'], observed_bounds['upper'], pred['op'], pred['value'])
        conclusion = count_conclusion(bounds['lower'], bounds['upper'], pred['op'], pred['value'])
        actual_matches = result['observed_condition_satisfied'] == observed and result['conclusion'] == conclusion and result['included_in_audience'] is (conclusion is True)
        actual_matches = actual_matches and result['observed_event_presence'] is (evidence['observed_event_count'] > 0)
        actual_matches = actual_matches and evidence['observed_matching_event_count'] <= evidence['observed_event_count'] and evidence['observed_measure_value'] == observed_bounds['lower']
        run.check('result_evidence_semantics_' + str(index + 1), actual_matches, 'Presenza di eventi, soddisfacimento osservato e conclusione derivano dai rispettivi conteggi.', [12], calculated_observed_condition_satisfied=observed, calculated_conclusion=conclusion)
    scenarios = [scenario for example in examples for scenario in example.get('resolution_scenarios', [])]
    run.check('resolution_scenarios_present', len(scenarios) >= 2, 'Sono presenti scenari espliciti di ambiguità e indisponibilità.', [10])
    # Check actual known scenario outcomes, without simulating an LLM resolver.
    statuses = {node.get('status') for scenario in scenarios for node in walk(scenario) if 'status' in node}
    run.check('ambiguity_and_unconfigured_outcomes', {'ambiguous', 'unavailable'} <= statuses, 'I casi di ambiguità e login non configurato espongono esiti distinti.', [10, 12], statuses=sorted(str(s) for s in statuses))


def cart_candidate_reference(case, context):
    """One supplied anchor only; not a stateful cart or production event engine."""
    anchor = case['anchor']
    start, end = parse_datetime(context['from']), parse_datetime(context['as_of'])
    cutoff = end.astimezone(UTC) - timedelta(hours=context['grace_hours'])
    anchor_time = parse_datetime(anchor['event_time'])
    if not start <= anchor_time < cutoff:
        return False
    cart_id = lookup(anchor, 'properties.cart_id')
    if cart_id is MISSING or cart_id is None:
        return UNKNOWN
    uncertain = False
    for followup in case['followups']:
        when = parse_datetime(followup['event_time'])
        if followup['profile_id'] != anchor['profile_id'] or when < anchor_time or not start <= when < end:
            continue
        followup_cart = lookup(followup, 'properties.cart_id')
        if followup_cart is MISSING or followup_cart is None:
            uncertain = True
        elif followup_cart == cart_id:
            if when == anchor_time:
                uncertain = True
            else:
                return False
    return UNKNOWN if uncertain or case['coverage'] != 'complete' else True


def semantic_checks(run):
    fixture = run.fixtures['semantic-cases.json']
    example = next(e for e in run.documents['mcp']['examples'] if e['example_id'].startswith('07_'))
    conditions = example['query']['where']['event']['where']
    run.check('product_conditions_match_fixtures', conditions == fixture['property_conditions'], 'Le fixture verificano le condizioni presenti nell’esempio consegnato.', [10, 12])
    for case in fixture['property_cases']:
        actual = tri_all([property_match(c, case['payload']) for c in conditions])
        run.check('reference_' + case['id'], actual == case['expected'], 'Predicati di proprietà sullo stesso evento ed elemento products.', [7, 10, 12], ['mcp_67:reference_' + case['id']], actual=actual, expected=case['expected'])
    for case in fixture['count_cases']:
        actual = count_conclusion(case['lower'], case['upper'], case['predicate']['op'], case['predicate']['value'])
        run.check('reference_' + case['id'], actual == case['expected'], 'Conclusione a tre stati derivata dai limiti del conteggio.', [12], ['mcp_67:reference_' + case['id']], actual=actual, expected=case['expected'])
    for case in fixture['boolean_cases']:
        actual = {'all': tri_all, 'any': tri_any}.get(case['op'], lambda values: tri_not(values[0]))(case['values'])
        run.check('boolean_' + case['id'], actual == case['expected'], 'Logica ternaria per combinazioni e negazioni.', [12], actual=actual, expected=case['expected'])
    for case in fixture['cart_cases']:
        actual = cart_candidate_reference(case, fixture['cart_context'])
        run.check('cart_fixture_' + case['id'], actual == case['expected'], 'Correlazione e grace sul solo anchor della fixture.', [11, 12], actual=actual, expected=case['expected'])


def temporal_checks(run):
    actual_legacy_map = {'elapsed_7d_fall': 'elapsed_hours_last_7_days', 'elapsed_30d_fall': 'elapsed_hours_last_30_days', 'elapsed_90d_fall': 'elapsed_hours_last_90_days', 'rolling_7d_fall': 'dst_transition_really_crossed'}
    for case in run.fixtures['temporal-cases.json']['cases']:
        actual, error = None, None
        try:
            resolved = resolve_window(case['temporal_spec'], case['as_of'], case['timezone'])
            actual = {'from': resolved['from'], 'to': resolved['to'], 'elapsed_seconds': resolved['derivation']['elapsed_seconds']}
        except (ValueError, ZoneInfoNotFoundError) as exc:
            error = str(exc)
        passed = error == case['expected_error'] if 'expected_error' in case else error is None and actual == case['expected']
        legacy = ['mcp_67:' + actual_legacy_map[case['id']]] if case['id'] in actual_legacy_map else []
        run.check('temporal_' + case['id'], passed, 'Fixture temporale indipendente: durata, calendario, gap o fold DST.', [11], legacy, actual=actual, error=error, expected=case.get('expected', case.get('expected_error')))


def apply_mutation(document, mutation):
    parts = [p.replace('~1', '/').replace('~0', '~') for p in mutation['path'].split('/')[1:]]
    value = document
    for part in parts[:-1]:
        value = value[int(part)] if isinstance(value, list) else value[part]
    key = int(parts[-1]) if isinstance(value, list) else parts[-1]
    if mutation['operation'] == 'remove':
        del value[key]
    elif mutation['operation'] == 'replace':
        value[key] = copy.deepcopy(mutation['value'])
    else:
        raise ValueError('Unsupported fixture mutation operation')


def negative_checks(run):
    examples = {e['example_id'][:2]: e['query'] for e in run.documents['mcp']['examples']}
    definitions = {d['id']: d for d in run.documents['catalog']['definitions']}
    catalog_version = run.documents['catalog']['catalog_version']
    old_catalog = {'missing_semantic_id', 'standard_without_source', 'standard_without_reference', 'documented_property_without_source', 'track_uses_name', 'compatibility_enabled_by_default', 'invalid_definition_version', 'invalid_verification_date'}
    old_mcp = {'unsupported_dsl_version', 'missing_definition_version', 'unknown_keyword', 'in_scalar_operand', 'in_empty_operand', 'datetime_without_offset', 'invalid_calendar_date'}
    for case in run.fixtures['negative-cases.json']['cases']:
        target = case['target']
        fixture = copy.deepcopy(examples[target[-2:]] if target.startswith('query') else run.documents[target])
        apply_mutation(fixture, case)
        for mutation in case.get('additional_mutations', []):
            apply_mutation(fixture, mutation)
        if case['phase'] == 'schema':
            validator = run.validators['query' if target.startswith('query') else target]
            errors = [e.message for e in validator.iter_errors(fixture)]
            passed = bool(errors)
        elif target.startswith('query'):
            errors = query_semantic_errors(fixture, definitions, catalog_version, case.get('enabled_ids'))
            passed = case['expected_error_code'] in errors
        elif target == 'bindings':
            errors = ['UNKNOWN_DEFINITION' for b in fixture['bindings'] if b['target_definition_id'] not in definitions]
            passed = case['expected_error_code'] in errors
        else:
            raise ValueError('Unsupported semantic negative fixture')
        legacy = []
        if case['id'] in old_catalog:
            legacy.append('catalog_55:schema_rejects_' + case['id'])
        if case['id'] in old_mcp:
            legacy.append('mcp_67:negative_' + case['id'])
        run.check('negative_' + case['id'], passed, 'La fixture non valida è respinta nella fase dichiarata.', [2, 5, 6, 9, 10, 11, 12], legacy, rejection_phase=case['phase'], errors=errors[:5])


def build_recovery(run):
    inventory = run.fixtures.get('legacy-test-inventory.json', {}).get('original_suites', {})
    mapping = defaultdict(list)
    for check in run.checks:
        for ref in check['legacy_test_refs']:
            mapping[ref].append(check['id'])
    # Changes below alter the file contract or implementation, not the intended test.
    adapted = {
        'catalog_55:draft_2020_12_metaschema', 'catalog_55:catalog_json_schema',
        'catalog_55:binding_references', 'catalog_55:binding_name_matcher_consistency',
        'catalog_55:complete_legacy_aliases', 'catalog_55:source_registry_coverage',
        'catalog_55:declared_counts', 'catalog_55:schema_rejects_compatibility_enabled_by_default',
        'catalog_55:input_unchanged_during_validation',
        'mcp_67:draft202012_schema_meta_validation', 'mcp_67:catalog_versions_match_seed',
        'mcp_67:all_11_event_windows_valid', 'mcp_67:historical_and_recent_windows_contiguous',
        'mcp_67:execution_fixture_consistent_in_9_examples',
        'mcp_67:seed_supplementary_source_uri_formats', 'mcp_67:source_uri_negative_fixture_rejected',
        'mcp_67:seed_remained_byte_identical', 'mcp_67:dst_transition_really_crossed',
    }
    result = []
    for suite, data in inventory.items():
        for check in data['checks']:
            ref = suite + ':' + check['id']
            executed = mapping.get(ref, [])
            if not executed:
                status = 'not_recovered'
            elif ref in adapted or check['id'].startswith(('schema_0', 'datetime_profile_0')):
                status = 'adapted'
            else:
                status = 'retained'
            result.append({'original_suite': suite, 'original_check_id': check['id'], 'recovery': status, 'executed_check_ids': executed})
    return result


def write_reports(run):
    counts = Counter(check['status'] for check in run.checks)
    passed = counts['failed'] == 0 and bool(run.checks)
    run.recovery = build_recovery(run)
    recovery_counts = {suite: dict(Counter(row['recovery'] for row in run.recovery if row['original_suite'] == suite)) for suite in ('catalog_55', 'mcp_67')}
    coverage = []
    for number, title in USER_REQUIREMENTS.items():
        selected = [c for c in run.checks if number in c['user_requirement_ids']]
        coverage.append({'requirement': number, 'description': title, 'checks_executed': len(selected), 'checks_passed': sum(c['status'] == 'passed' for c in selected), 'checks_failed': sum(c['status'] == 'failed' for c in selected)})
    limitations = [
        'Nessun backend CDP, server MCP, SQL, SDK vendor o tenant reale è stato eseguito o contattato.',
        'Matcher, predicati, conteggi, logica ternaria, singoli anchor del carrello e risoluzione temporale sono implementazioni locali di riferimento limitate alle fixture dichiarate; non sono un motore completo della DSL.',
        'La validazione non dimostra copertura degli eventi reali, correttezza della strumentazione, disponibilità degli snapshot, identity resolution, autorizzazioni o finalizzazione degli eventi in ritardo.',
        'I contratti dei sei tool sono proposte applicative. Vengono controllate la coerenza logica e le query, non una negoziazione MCP tools/list o l’esecuzione dei tool.',
        'Le fonti non sono state nuovamente scaricate. Si controllano struttura, URI, provenienza dichiarata e completezza rispetto agli inventari della ricerca recuperati.',
        'Python 3.10+ è il requisito di sintassi e dipendenze; l’unico interprete realmente eseguito in questa sessione è quello registrato in runtime.',
        'Il risolutore temporale richiede offset noto, respinge -00:00 e secondi intercalari; le durate effettive si calcolano sempre in UTC. La base IANA è fornita dalla dipendenza tzdata registrata, non dal sistema operativo.',
    ]
    differences = [
        'La revisione di riferimento conserva 102 concetti e 16 binding; i conteggi effettivi e l’esito del confronto con gli inventari originali sono riportati sopra. Il registro dei binding è ora un file separato.',
        'Versioni di catalogo, schemi e DSL portate a 1.1.0; definition_version resta 1 per tutte le definizioni.',
        'Il campo ambiguo observed_match è sostituito dalla presenza degli eventi osservati, dalla condizione soddisfatta sui dati disponibili e dalla conclusione true/false/unknown basata sui limiti di evidenza.',
        'La DSL distingue ore trascorse, giorni locali mobili, giorni locali completi e intervalli assoluti. I casi 23/25 ore e i bound locali ambigui o inesistenti sono fixture esplicite.',
        'Le suite originali 55 e 67 sono recuperate come inventario; test uniti o adattati sono mappati singolarmente. Il numero della nuova esecuzione è calcolato e non viene forzato a 122.',
        'Il vecchio validator MCP correggeva il JSON durante la validazione. Questa versione legge soltanto gli input e verifica che i loro hash restino invariati.',
        'URI, date e date-time sono ora verificati da checker effettivamente registrati tramite jsonschema[format], con fixture positive e negative.',
    ]
    report = {
        'validation_report_version': VERSION, 'generated_at_utc': utc_string(datetime.now(UTC)),
        'status': 'passed' if passed else 'failed', 'exit_code': 0 if passed else 1,
        'runtime': run.runtime, 'format_checkers': run.formats,
        'validator_script': {'filename': Path(__file__).name, 'sha256': sha256(Path(__file__).read_bytes())},
        'input_files': run.inputs, 'counts': run.counts, 'completeness': run.completeness,
        'summary': {'checks_executed': len(run.checks), 'checks_passed': counts['passed'], 'checks_failed': counts['failed'], 'new_checks': sum(not c['legacy_test_refs'] for c in run.checks)},
        'user_requirements': coverage, 'legacy_test_recovery_summary': recovery_counts,
        'legacy_test_recovery': run.recovery, 'checks': run.checks,
        'differences_and_corrections': differences, 'limitations': limitations,
        'reproduction': {'install': 'python -m pip install -r requirements.txt', 'run': 'python validate_catalog.py', 'alternate_directory': 'python validate_catalog.py --directory PATH', 'outputs': ['validation-results.json', 'validation-report.md'], 'input_mutation': 'none'},
    }
    target = run.directory / 'validation-results.json'
    target.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    md = [
        '# Rapporto di validazione del catalogo CDP', '',
        '**Esito: ' + ('SUPERATO' if passed else 'FALLITO') + '.** ' + str(len(run.checks)) + ' controlli realmente eseguiti: ' + str(counts['passed']) + ' superati, ' + str(counts['failed']) + ' falliti.', '',
        'Esecuzione UTC: ' + report['generated_at_utc'] + '. Python ' + run.runtime.get('python', 'non rilevato') + '; jsonschema ' + run.runtime.get('jsonschema', 'non disponibile') + '; Draft 2020-12.', '',
        'Il conteggio comprende controlli strutturali, riferimenti, fixture positive e negative e funzioni locali di riferimento. Non corrisponde a query eseguite su un backend di produzione.', '',
        '## Inventario effettivo', '',
        '| Gruppo | Definizioni |', '|---|---:|',
    ]
    for name, value in run.counts.get('by_requested_group', {}).items():
        md.append('| ' + name + ' | ' + str(value) + ' |')
    md += ['', 'Totale definizioni: **' + str(run.counts.get('definitions', 'non calcolato')) + '**. Binding separati: **' + str(run.counts.get('bindings', 'non calcolato')) + '**.', '', '| Provenienza | Definizioni |', '|---|---:|']
    for name, value in run.counts.get('by_origin', {}).items():
        md.append('| ' + name + ' | ' + str(value) + ' |')
    md += ['', '| Catalogo primario | Definizioni |', '|---|---:|']
    for name, value in run.counts.get('by_primary_catalog', {}).items():
        md.append('| ' + name + ' | ' + str(value) + ' |')
    md += ['', '## Copertura dei 12 requisiti', '', 'Un controllo può coprire più requisiti; le righe non si sommano al totale.', '', '| N. | Requisito | Eseguiti | Superati | Falliti |', '|---:|---|---:|---:|---:|']
    for row in coverage:
        md.append('| {requirement} | {description} | {checks_executed} | {checks_passed} | {checks_failed} |'.format(**row))
    md += ['', '## Recupero dei test precedenti', '', '| Suite originale | Conservati | Adattati | Non recuperati |', '|---|---:|---:|---:|']
    for suite, values in recovery_counts.items():
        md.append('| ' + suite + ' | ' + str(values.get('retained', 0)) + ' | ' + str(values.get('adapted', 0)) + ' | ' + str(values.get('not_recovered', 0)) + ' |')
    md += ['', 'Nuovi controlli senza corrispondenza diretta nelle suite originali: **' + str(report['summary']['new_checks']) + '**. La mappatura di ogni vecchio ID ai controlli effettivamente eseguiti è in `validation-results.json`, sezione `legacy_test_recovery`.', '']
    missing = [row for row in run.recovery if row['recovery'] == 'not_recovered']
    if missing:
        md += ['Test non recuperati:', ''] + ['- ' + row['original_suite'] + ': ' + row['original_check_id'] for row in missing] + ['']
    else:
        md += ['Tutti gli ID delle due suite originali hanno una corrispondenza eseguita; alcuni controlli condividono il nuovo test che li sostituisce.', '']
    md += ['## Anomalie e correzioni', '']
    failures = [c for c in run.checks if c['status'] == 'failed']
    if failures:
        md += ['- **' + c['id'] + '**: ' + c['description'] + ' Dettagli: `' + json.dumps(c.get('details', {}), ensure_ascii=False).replace('`', "'") + '`' for c in failures]
    else:
        md += ['Nessun errore rilevato nell’esecuzione indicata. Le correzioni progettuali rispetto al rapporto precedente sono elencate qui sotto.']
    md += [''] + ['- ' + text for text in differences]
    md += ['', '## Formati, calendario e integrità', '',
           'Checker registrati: `' + json.dumps(run.formats, ensure_ascii=False) + '`. La disponibilità viene verificata prima di accettare gli esiti dei formati; fixture errate devono essere respinte.', '',
           'Base timezone: `' + str(run.runtime.get('timezone_database', 'non registrata')) + '`. Le finestre sono ricalcolate indipendentemente dai bound consegnati.', '',
           'Gli hash SHA-256 di tutti i JSON e fixture letti sono in `input_files` del rapporto JSON. Il controllo finale verifica che gli input non siano cambiati.']
    md += ['', '## Riproduzione', '', 'Richiede Python 3.10 o successivo. Dalla cartella degli artefatti:', '', '```bash', 'python -m pip install -r requirements.txt', 'python validate_catalog.py', '```', '',
           'Il percorso degli input è risolto rispetto a `__file__`, quindi il comando funziona anche da un’altra directory. `--directory PATH` seleziona un’altra cartella con gli stessi file. Lo script aggiorna soltanto i due rapporti; restituisce exit code 0 se tutti i controlli passano, 1 se rileva errori.', '', '## Limiti', '']
    md += ['- ' + text for text in limitations]
    (run.directory / 'validation-report.md').write_text('\n'.join(md) + '\n', encoding='utf-8')
    print(json.dumps({'status': report['status'], 'summary': report['summary'], 'legacy_recovery': recovery_counts, 'failed_checks': [c['id'] for c in failures]}, ensure_ascii=False, indent=2))
    return report['exit_code']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', type=Path, default=Path(__file__).resolve().parent, help='Directory containing the complete delivered artefacts and fixtures.')
    args = parser.parse_args()
    directory = args.directory.resolve()
    if not directory.is_dir():
        print('Input directory does not exist: ' + str(directory), file=sys.stderr)
        return 1
    run = Run(directory)
    if sys.version_info < (3, 10):
        run.check('python_version', False, 'È richiesto Python 3.10 o successivo.')
        return write_reports(run)
    try:
        import jsonschema  # noqa: F401 -- dependency availability is an explicit gate
        import tzdata  # noqa: F401
        # Force the declared portable database; do not silently use the OS TZPATH.
        reset_tzpath(())
        ZoneInfo.clear_cache()
        run.runtime['timezone_database'] = 'tzdata ' + importlib.metadata.version('tzdata')
    except ImportError as exc:
        run.check('dependencies_available', False, 'Installare le dipendenze dichiarate in requirements.txt prima della validazione.', error=str(exc))
        return write_reports(run)
    loaded = run.load()
    if loaded:
        for name, function in [('schemas', schema_checks), ('catalog', catalog_checks), ('matchers', matcher_checks), ('mcp', mcp_checks), ('semantics', semantic_checks), ('time', temporal_checks), ('negative', negative_checks)]:
            run.phase(name, function)
    run.protect_inputs()
    return write_reports(run)


if __name__ == '__main__':
    sys.exit(main())


