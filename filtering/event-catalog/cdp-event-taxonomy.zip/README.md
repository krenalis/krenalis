# Catalogo eventi CDP per Segment e RudderStack

Versione del pacchetto: **1.1.0**. Verifica documentale originaria: **29 ottobre 2026**.

Il JSON è il formato principale e autorevole. Il pacchetto recupera il seed della ricerca precedente: **102 definizioni**, con i medesimi identificatori, contenuti e `definition_version: 1`. La versione 1.1.0 separa i binding e rende esplicite la valutazione delle condizioni e la derivazione delle finestre temporali. Non è un Tracking Plan direttamente importabile nei prodotti Segment o RudderStack.

## File

| File | Contenuto |
| --- | --- |
| `cdp-event-catalog.json` | 102 definizioni complete, 20 campi ciascuna, cataloghi, preset, inventari e fonti. |
| `cdp-event-catalog.schema.json` | JSON Schema Draft 2020-12 del catalogo. |
| `cdp-event-bindings.json` | 16 varianti tecniche, tutte disabilitate e soggette a validazione amministrativa. |
| `cdp-event-bindings.schema.json` | Schema del registro separato dei binding. |
| `cdp-mcp-examples.json` | 9 esempi di query, 3 scenari di risoluzione, 4 esempi di risultato e contratti applicativi MCP. |
| `cdp-filter-dsl.schema.json` | Schema standalone della DSL, inclusi i tipi di risultato in `$defs`. |
| `validate_catalog.py` | Runner riproducibile: struttura, riferimenti, matcher, semantica, tempo e fixture. |
| `requirements.txt` | Dipendenze Python con versioni fissate. |
| `fixtures/` | Inventari attesi e casi di prova positivi, negativi, semantici e temporali. |
| `validation-report.md` | Rapporto leggibile generato dall'esecuzione effettiva dei test. |
| `validation-results.json` | Esito dettagliato dei test, metadati del runtime e hash degli input. |
| `cdp-event-catalog.csv` | Tutti i 20 campi del catalogo; UTF-8 con BOM, oggetti e array come JSON nelle celle. |
| `cdp-event-catalog.xlsx` | Fogli filtrabili Catalogo e Bindings, rispettivamente 102 × 20 e 16 × 23. |
| `MANIFEST.sha256` | Hash dei file consegnati, esclusi il manifest stesso e l'archivio. |
| `cdp-event-taxonomy.zip` | Pacchetto completo, mantenendo la directory `fixtures`. |

## Validazione

Estrarre l'intero ZIP, mantenendo i nomi e la struttura delle cartelle. Usare Python 3.10 o successivo; la versione effettivamente eseguita è riportata nel rapporto. È consigliabile usare un ambiente virtuale.

```bash
python -m pip install -r requirements.txt
python validate_catalog.py
```

Per validare un'altra copia completa del pacchetto:

```bash
python validate_catalog.py --directory /percorso/del/pacchetto
```

Il runner usa per impostazione predefinita la cartella dello script, non la directory corrente. Restituisce codice di uscita `0` se tutti i controlli passano, `1` in presenza di errori. Non modifica catalogo, schemi, esempi o fixture: scrive soltanto `validation-results.json` e `validation-report.md` nella directory selezionata. La nuova esecuzione può cambiare timestamp e hash dei due rapporti rispetto al manifest della consegna.

L'installazione iniziale richiede l'accesso alle dipendenze Python. I test non interrogano i provider, non chiamano un server MCP e non richiedono credenziali. Il controllo degli URL è sintattico; non ripete la ricerca documentale.

Le fixture rappresentano il contratto di questa versione. Una personalizzazione intenzionale del catalogo può richiedere l'aggiornamento dei relativi inventari attesi; non basta cambiare i conteggi dichiarati nel JSON per superare i controlli di completezza.

## Distribuzione e provenienza

| Gruppo | Definizioni |
| --- | ---: |
| General Website | 17 |
| Ecommerce | 36 |
| Moduli opzionali | 48 |
| Tecnico storico | 1 |
| **Totale** | **102** |

La provenienza è **71 A, 16 B, 14 C, 1 D**. A indica una definizione in una specifica o API ufficiale del vendor; B un nome attestato in una raccomandazione o esempio ufficiale; C una proposta CDP; D compatibilità storica. Una voce A può essere ufficiale per un solo provider. Per B, la fonte può attestare il nome senza garantire tutte le soglie o proprietà proposte dal contratto locale.

CSV ed Excel sono stati generati dai JSON consegnati e confrontati integralmente con essi durante l'esportazione. Tale controllo degli export è separato dalla suite del runner; il JSON rimane la fonte da usare per importazione e personalizzazione.

`catalog` è l'appartenenza primaria; `related_catalogs` e `catalog_membership` permettono di riusare una definizione senza duplicarla. I 20 campi di ogni definizione sono presenti anche nel CSV e nel foglio Catalogo.

`key_properties` è una selezione semantica, non lo schema completo di ingestione. La provenienza della singola proprietà distingue `documented` e `cdp_suggested`. `recommended_business_key` è una raccomandazione da verificare sui dati effettivi, non una garanzia che il campo sia sempre presente.

## Importazione e versionamento

1. Validare i JSON con gli schemi forniti ed eseguire i controlli referenziali del runner.
2. Importare le definizioni usando la chiave `(id, definition_version)`; conservare immutabili le versioni già referenziate.
3. Importare il registro dei binding come configurazione separata. Tutte le varianti rimangono disabilitate nel template.
4. Configurare le sorgenti reali, la normalizzazione dell'envelope, le proprietà e il contratto di emissione prima di rendere un evento interrogabile.
5. Associare esplicitamente gli eventi ai profili e documentare copertura, deduplica, identità e gestione dei dati tardivi.

`enabled_by_default` seleziona il preset; non attiva la raccolta e non dimostra copertura. Gli stati disponibili, abilitati, configurati, osservati e verificati devono essere distinti. Una definizione non configurata produce un errore di validazione, non un conteggio zero.

I matcher usano `type` e, per `track`, `event`. `page` e `screen` possono essere riconosciuti senza `name`; `identify`, `group` e `alias` non hanno un nome di azione equivalente a `event`. I confronti sono esatti e sensibili alle maiuscole. Un record che soddisfa più rami OR si conta una volta. La deduplica di più messaggi dello stesso ordine è una decisione separata.

I binding comprendono 12 alias storici, 3 varianti User Signed e il candidato Purchase Completed. `provider` identifica il provider della documentazione citata: non dimostra quale connettore emetta la variante nel tenant. La verifica amministrativa rimane necessaria. Non unificare automaticamente Order Created, Order Completed e Purchase Completed.

Un nuovo concetto richiede un nuovo `id`; revisioni del matcher o dei binding richiedono nuove versioni. La versione del catalogo 1.1.0 non incrementa automaticamente le versioni delle singole definizioni. I filtri salvati devono fissare le versioni semantiche e del binding set; le esecuzioni riproducibili richiedono anche snapshot e policy di identità.

## Evidenza osservata e conclusione

Il campo ambiguo `observed_match` è stato eliminato dalla proposta applicativa.

- `observed_event_count`: istanze riconosciute dalla definizione nella finestra, dopo la deduplica prevista e prima del filtro sulle proprietà.
- `observed_matching_event_count`: istanze che soddisfano certamente anche `event.where`.
- `observed_measure_value`: misura minima certamente osservata; per prodotti distinti può differire dal numero di eventi.
- `observed_count_bounds`: limiti della misura usando soltanto i record osservati, compresi candidati con proprietà ignote.
- `observed_condition_satisfied`: esito del predicato sui dati osservati, con valori `true`, `false` o `"unknown"`.
- `reliability`: copertura, identità e disponibilità delle proprietà, senza significato probabilistico.
- `conclusion`: esito della condizione nel perimetro dichiarato, includendo anche le lacune di raccolta.

Per zero eventi osservati e condizione `count = 0`, la presenza osservata è falsa e la condizione sui record osservati è vera. Con copertura ignota, la conclusione resta `"unknown"`. Un evento osservato con proprietà necessarie mancanti non scompare: può rendere indeterminata anche la condizione sui soli dati osservati.

Tre view dello stesso prodotto producono tre istanze e un prodotto distinto. Il predicato si applica alla misura scelta, non sempre a `observed_event_count`. Con `include_true_only`, entrano nell'audience soltanto i risultati con `conclusion: true`.

## Finestre temporali

Ogni selettore dichiara `temporal_spec`, estremi UTC semiaperti `[from,to)` e `derivation`. Il validatore ricalcola gli estremi e confronta rappresentazioni locali e durata effettiva.

| Modalità | Significato |
| --- | --- |
| `elapsed_hours` | Durata trascorsa, sottratta all'istante `as_of` in UTC. |
| `rolling_local_calendar_days` | N date civili precedenti, mantenendo l'ora locale di `as_of`. |
| `previous_complete_calendar_days` | N giorni locali completi precedenti il giorno corrente; oggi escluso. |
| `absolute_interval` | Due istanti espliciti con offset, normalizzati in UTC. |

Nell'esempio con `as_of = 2026-10-29T12:00:00+01:00`, timezone `Europe/Rome`:

| Interpretazione | Inizio locale | Fine locale | Ore trascorse |
| --- | --- | --- | ---: |
| Ultime 720 ore | 29 settembre, 13:00 +02:00 | 29 ottobre, 12:00 +01:00 | 720 |
| Ultimi 30 giorni rolling locali | 29 settembre, 12:00 +02:00 | 29 ottobre, 12:00 +01:00 | 721 |
| 30 giorni locali completi precedenti oggi | 29 settembre, 00:00 +02:00 | 29 ottobre, 00:00 +01:00 | 721 |

Non esiste una conversione universale “30 giorni = 720 ore”. Per orari locali ambigui il contratto richiede `reject`, `earlier` o `later` espliciti. Gli orari locali inesistenti sono respinti. Gli istanti assoluti richiedono un offset noto; il profilo non accetta secondi intercalari né offset `-00:00`.

## Ambito MCP e limiti

Nomi dei tool, DSL, valutatore ternario e policy temporali sono contratti proposti per la CDP; non sono API esistenti dei provider né funzionalità che MCP implementa automaticamente. Gli esempi hanno ID reali del catalogo, ma profili, snapshot, attributi e binding di esecuzione sono fixture dichiarate.

La validazione verifica il contratto e un valutatore di riferimento limitato. Non implementa un motore di query di produzione, né verifica SQL, performance, autorizzazioni operative, copertura reale delle sorgenti o risoluzione dell'identità di un tenant. Il rapporto di validazione documenta il recupero dei test precedenti, gli adattamenti, le aggiunte e le anomalie effettivamente rilevate.
